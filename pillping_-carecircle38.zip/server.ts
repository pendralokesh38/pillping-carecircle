import 'dotenv/config';
import express, { type Request, type Response } from 'express';
import fs from 'node:fs';
import path from 'node:path';
import {
  confirmDoseSafely,
  getDb,
  getLocalDateStr,
  getLocalTimeHHMM,
  getPatientDashboardData,
  resetAndSeedSampleDataset,
  runMissedDoseEscalations,
} from './src/db/database.ts';
import {
  checkRefillWarning,
  formatTime12Hour,
  parseTimeToMinutes,
  validateImageDataUrl,
  validatePhoneNumber,
} from './src/logic/scheduling.ts';

const PORT = Number(process.env.PORT || 3000);
const IS_PROD = process.env.NODE_ENV === 'production';

// SSE clients registry
const sseClients = new Set<Response>();

function broadcastEvent(eventType: string, payload: Record<string, unknown>): void {
  const data = JSON.stringify({ type: eventType, ...payload, timestamp: new Date().toISOString() });
  for (const res of sseClients) {
    try {
      res.write(`event: ${eventType}\n`);
      res.write(`data: ${data}\n\n`);
    } catch {
      sseClients.delete(res);
    }
  }
}

function parseClientClock(req: Request): { todayStr: string; nowMinutes: number } {
  const qDate = typeof req.query.date === 'string' ? req.query.date : undefined;
  const qTime = typeof req.query.time === 'string' ? req.query.time : undefined;
  const bDate =
    req.body && typeof req.body.log_date === 'string' ? req.body.log_date : undefined;
  const bTime =
    req.body && typeof req.body.current_time === 'string' ? req.body.current_time : undefined;

  const dateCandidate = qDate || bDate;
  const timeCandidate = qTime || bTime;

  const todayStr =
    dateCandidate && /^\d{4}-\d{2}-\d{2}$/.test(dateCandidate)
      ? dateCandidate
      : getLocalDateStr();

  let nowMinutes = parseTimeToMinutes(getLocalTimeHHMM());
  if (timeCandidate && /^([01]?\d|2[0-3]):([0-5]\d)$/.test(timeCandidate)) {
    nowMinutes = parseTimeToMinutes(timeCandidate);
  }

  return { todayStr, nowMinutes };
}

async function startServer(): Promise<void> {
  const db = getDb();
  const app = express();

  app.use(express.json({ limit: '4mb' }));

  // Health Check
  app.get('/api/health', (_req: Request, res: Response) => {
    res.json({ status: 'ok', database: 'sqlite', timestamp: new Date().toISOString() });
  });

  // Server-Sent Events (SSE) for real-time Senior <-> Caregiver synchronization
  app.get('/api/events', (req: Request, res: Response) => {
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');
    res.flushHeaders?.();

    res.write(`event: connected\ndata: ${JSON.stringify({ ok: true })}\n\n`);
    sseClients.add(res);

    const keepAlive = setInterval(() => {
      try {
        res.write(': keepalive\n\n');
      } catch {
        clearInterval(keepAlive);
        sseClients.delete(res);
      }
    }, 25000);

    req.on('close', () => {
      clearInterval(keepAlive);
      sseClients.delete(res);
    });
  });

  // List Patients + Primary Caregiver
  app.get('/api/patients', (_req: Request, res: Response) => {
    const patients = db
      .prepare(`
        SELECT p.*,
          c.id AS caregiver_id,
          c.name AS caregiver_name,
          c.email AS caregiver_email,
          c.contact_number AS caregiver_phone,
          c.relationship AS caregiver_relationship
        FROM patients p
        LEFT JOIN caregivers c ON c.patient_id = p.id
        ORDER BY p.id ASC
      `)
      .all();
    res.json({ patients });
  });

  // Full Synchronized Dashboard State for a Patient
  app.get('/api/patients/:id/dashboard', (req: Request, res: Response) => {
    const patientId = Number(req.params.id);
    if (!Number.isInteger(patientId) || patientId <= 0) {
      res.status(400).json({ error: 'Invalid patient ID.' });
      return;
    }
    const { todayStr, nowMinutes } = parseClientClock(req);
    runMissedDoseEscalations(db, todayStr, nowMinutes);
    const data = getPatientDashboardData(db, patientId, todayStr, nowMinutes);
    if (!data) {
      res.status(404).json({ error: 'Patient not found.' });
      return;
    }
    res.json(data);
  });

  // Update Patient & Caregiver Emergency SOS Contact
  app.put('/api/patients/:id/contact', (req: Request, res: Response) => {
    const patientId = Number(req.params.id);
    if (!Number.isInteger(patientId) || patientId <= 0) {
      res.status(400).json({ error: 'Invalid patient ID.' });
      return;
    }

    const { caregiver_name, caregiver_email, caregiver_phone, caregiver_relationship, preferred_greeting } =
      req.body ?? {};

    if (!caregiver_name || typeof caregiver_name !== 'string' || !caregiver_name.trim()) {
      res.status(400).json({ error: 'Caregiver name is required.' });
      return;
    }

    const phoneCheck = validatePhoneNumber(String(caregiver_phone ?? ''));
    if (!phoneCheck.valid) {
      res.status(400).json({ error: phoneCheck.error });
      return;
    }

    const existingPatient = db.prepare('SELECT id FROM patients WHERE id = ?').get(patientId);
    if (!existingPatient) {
      res.status(404).json({ error: 'Patient not found.' });
      return;
    }

    if (typeof preferred_greeting === 'string' && preferred_greeting.trim()) {
      db.prepare('UPDATE patients SET preferred_greeting = ? WHERE id = ?').run(
        preferred_greeting.trim().slice(0, 40),
        patientId
      );
    }

    const existingCaregiver = db
      .prepare('SELECT id FROM caregivers WHERE patient_id = ? LIMIT 1')
      .get(patientId) as { id: number } | undefined;

    if (existingCaregiver) {
      db.prepare(`
        UPDATE caregivers
        SET name = ?, email = ?, contact_number = ?, relationship = ?
        WHERE id = ?
      `).run(
        caregiver_name.trim().slice(0, 80),
        String(caregiver_email ?? '').trim().slice(0, 120),
        phoneCheck.normalized,
        String(caregiver_relationship ?? 'Primary Caregiver').trim().slice(0, 80),
        existingCaregiver.id
      );
    } else {
      db.prepare(`
        INSERT INTO caregivers (patient_id, name, email, contact_number, relationship)
        VALUES (?, ?, ?, ?, ?)
      `).run(
        patientId,
        caregiver_name.trim().slice(0, 80),
        String(caregiver_email ?? '').trim().slice(0, 120),
        phoneCheck.normalized,
        String(caregiver_relationship ?? 'Primary Caregiver').trim().slice(0, 80)
      );
    }

    broadcastEvent('patient:updated', { patientId });
    res.json({ ok: true });
  });

  // Create Medication + Schedules
  app.post('/api/medications', (req: Request, res: Response) => {
    const {
      patient_id,
      medicine_name,
      purpose_label,
      dosage,
      frequency,
      instructions,
      with_food,
      pill_color,
      remaining_quantity,
      bottle_image,
      schedules,
    } = req.body ?? {};

    const patientId = Number(patient_id);
    if (!Number.isInteger(patientId) || patientId <= 0) {
      res.status(400).json({ error: 'Valid patient_id is required.' });
      return;
    }
    if (!medicine_name || typeof medicine_name !== 'string' || !medicine_name.trim()) {
      res.status(400).json({ error: 'Medicine name is required.' });
      return;
    }
    if (!dosage || typeof dosage !== 'string' || !dosage.trim()) {
      res.status(400).json({ error: 'Dosage is required.' });
      return;
    }

    const qty = Number(remaining_quantity);
    if (!Number.isFinite(qty) || qty < 0) {
      res.status(400).json({ error: 'Remaining quantity must be 0 or greater.' });
      return;
    }

    const imgCheck = validateImageDataUrl(String(bottle_image ?? ''));
    if (!imgCheck.valid) {
      res.status(400).json({ error: imgCheck.error });
      return;
    }

    if (!Array.isArray(schedules) || schedules.length === 0) {
      res.status(400).json({ error: 'At least one scheduled time is required.' });
      return;
    }

    for (const s of schedules) {
      try {
        parseTimeToMinutes(String(s.scheduled_time ?? ''));
      } catch {
        res.status(400).json({ error: `Invalid schedule time: ${s.scheduled_time}` });
        return;
      }
      if (!['Morning', 'Afternoon', 'Night'].includes(String(s.schedule_period))) {
        res.status(400).json({ error: 'Schedule period must be Morning, Afternoon, or Night.' });
        return;
      }
    }

    const todayStr = getLocalDateStr();
    let newMedId = 0;

    db.exec('BEGIN TRANSACTION;');
    try {
      const mRes = db
        .prepare(`
          INSERT INTO medications (
            patient_id, medicine_name, purpose_label, dosage, frequency,
            instructions, with_food, pill_color, remaining_quantity, bottle_image, is_sample
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0)
        `)
        .run(
          patientId,
          medicine_name.trim().slice(0, 80),
          String(purpose_label ?? '').trim().slice(0, 80),
          dosage.trim().slice(0, 40),
          String(frequency ?? `${schedules.length}x Daily`).trim().slice(0, 40),
          String(instructions ?? 'Take with Water').trim().slice(0, 120),
          ['with_food', 'without_food', 'any'].includes(String(with_food)) ? with_food : 'any',
          ['blue', 'amber', 'coral', 'emerald', 'purple'].includes(String(pill_color))
            ? pill_color
            : 'blue',
          Math.floor(qty),
          String(bottle_image ?? '')
        );
      newMedId = Number(mRes.lastInsertRowid);

      const insertSched = db.prepare(`
        INSERT INTO dose_schedules (medication_id, scheduled_time, schedule_period, active)
        VALUES (?, ?, ?, 1)
      `);

      for (const s of schedules) {
        insertSched.run(newMedId, String(s.scheduled_time).trim(), s.schedule_period);
      }

      const refill = checkRefillWarning(Math.floor(qty));
      if (refill.isLow) {
        db.prepare(`
          INSERT INTO caregiver_alerts (
            patient_id, medication_id, schedule_id, alert_date, scheduled_time, alert_type, message, status
          ) VALUES (?, ?, NULL, ?, '', 'refill_low', ?, 'active')
        `).run(
          patientId,
          newMedId,
          todayStr,
          `${medicine_name.trim()} ${dosage.trim()} is running low (${Math.floor(qty)} pills remaining).`
        );
      }

      db.exec('COMMIT;');
    } catch (err) {
      db.exec('ROLLBACK;');
      throw err;
    }

    broadcastEvent('medication:updated', { patientId, medicationId: newMedId, action: 'created' });
    res.status(201).json({ ok: true, id: newMedId });
  });

  // Update Medication + Schedules
  app.put('/api/medications/:id', (req: Request, res: Response) => {
    const medId = Number(req.params.id);
    if (!Number.isInteger(medId) || medId <= 0) {
      res.status(400).json({ error: 'Invalid medication ID.' });
      return;
    }

    const existing = db
      .prepare('SELECT * FROM medications WHERE id = ?')
      .get(medId) as { id: number; patient_id: number; bottle_image: string } | undefined;
    if (!existing) {
      res.status(404).json({ error: 'Medication not found.' });
      return;
    }

    const {
      medicine_name,
      purpose_label,
      dosage,
      frequency,
      instructions,
      with_food,
      pill_color,
      remaining_quantity,
      bottle_image,
      schedules,
    } = req.body ?? {};

    if (!medicine_name || typeof medicine_name !== 'string' || !medicine_name.trim()) {
      res.status(400).json({ error: 'Medicine name is required.' });
      return;
    }
    if (!dosage || typeof dosage !== 'string' || !dosage.trim()) {
      res.status(400).json({ error: 'Dosage is required.' });
      return;
    }

    const qty = Number(remaining_quantity);
    if (!Number.isFinite(qty) || qty < 0) {
      res.status(400).json({ error: 'Remaining quantity must be 0 or greater.' });
      return;
    }

    const nextImage =
      bottle_image !== undefined ? String(bottle_image) : existing.bottle_image;
    const imgCheck = validateImageDataUrl(nextImage);
    if (!imgCheck.valid) {
      res.status(400).json({ error: imgCheck.error });
      return;
    }

    if (!Array.isArray(schedules) || schedules.length === 0) {
      res.status(400).json({ error: 'At least one scheduled time is required.' });
      return;
    }

    for (const s of schedules) {
      try {
        parseTimeToMinutes(String(s.scheduled_time ?? ''));
      } catch {
        res.status(400).json({ error: `Invalid schedule time: ${s.scheduled_time}` });
        return;
      }
      if (!['Morning', 'Afternoon', 'Night'].includes(String(s.schedule_period))) {
        res.status(400).json({ error: 'Schedule period must be Morning, Afternoon, or Night.' });
        return;
      }
    }

    const todayStr = getLocalDateStr();
    const safeQty = Math.floor(qty);

    db.exec('BEGIN TRANSACTION;');
    try {
      db.prepare(`
        UPDATE medications
        SET medicine_name = ?, purpose_label = ?, dosage = ?, frequency = ?,
            instructions = ?, with_food = ?, pill_color = ?, remaining_quantity = ?, bottle_image = ?
        WHERE id = ?
      `).run(
        medicine_name.trim().slice(0, 80),
        String(purpose_label ?? '').trim().slice(0, 80),
        dosage.trim().slice(0, 40),
        String(frequency ?? `${schedules.length}x Daily`).trim().slice(0, 40),
        String(instructions ?? 'Take with Water').trim().slice(0, 120),
        ['with_food', 'without_food', 'any'].includes(String(with_food)) ? with_food : 'any',
        ['blue', 'amber', 'coral', 'emerald', 'purple'].includes(String(pill_color))
          ? pill_color
          : 'blue',
        safeQty,
        nextImage,
        medId
      );

      // Update schedules cleanly while preserving existing matching times when possible
      db.prepare('UPDATE dose_schedules SET active = 0 WHERE medication_id = ?').run(medId);
      const insertSched = db.prepare(`
        INSERT INTO dose_schedules (medication_id, scheduled_time, schedule_period, active)
        VALUES (?, ?, ?, 1)
      `);
      for (const s of schedules) {
        insertSched.run(medId, String(s.scheduled_time).trim(), s.schedule_period);
      }

      const refill = checkRefillWarning(safeQty);
      if (refill.isLow) {
        const activeRefill = db
          .prepare(
            "SELECT id FROM caregiver_alerts WHERE medication_id = ? AND alert_type = 'refill_low' AND status = 'active'"
          )
          .get(medId) as { id: number } | undefined;
        const msg = `${medicine_name.trim()} ${dosage.trim()} is running low (${safeQty} pills remaining).`;
        if (activeRefill) {
          db.prepare('UPDATE caregiver_alerts SET message = ? WHERE id = ?').run(
            msg,
            activeRefill.id
          );
        } else {
          db.prepare(`
            INSERT INTO caregiver_alerts (
              patient_id, medication_id, schedule_id, alert_date, scheduled_time, alert_type, message, status
            ) VALUES (?, ?, NULL, ?, '', 'refill_low', ?, 'active')
          `).run(existing.patient_id, medId, todayStr, msg);
        }
      } else {
        db.prepare(
          "UPDATE caregiver_alerts SET status = 'resolved', resolved_at = datetime('now') WHERE medication_id = ? AND alert_type = 'refill_low' AND status = 'active'"
        ).run(medId);
      }

      db.exec('COMMIT;');
    } catch (err) {
      db.exec('ROLLBACK;');
      throw err;
    }

    broadcastEvent('medication:updated', {
      patientId: existing.patient_id,
      medicationId: medId,
      action: 'updated',
    });
    res.json({ ok: true });
  });

  // Delete Medication
  app.delete('/api/medications/:id', (req: Request, res: Response) => {
    const medId = Number(req.params.id);
    if (!Number.isInteger(medId) || medId <= 0) {
      res.status(400).json({ error: 'Invalid medication ID.' });
      return;
    }
    const existing = db
      .prepare('SELECT patient_id FROM medications WHERE id = ?')
      .get(medId) as { patient_id: number } | undefined;
    if (!existing) {
      res.status(404).json({ error: 'Medication not found.' });
      return;
    }

    db.prepare('DELETE FROM medications WHERE id = ?').run(medId);
    broadcastEvent('medication:updated', {
      patientId: existing.patient_id,
      medicationId: medId,
      action: 'deleted',
    });
    res.json({ ok: true });
  });

  // Refill Medication Inventory
  app.post('/api/medications/:id/refill', (req: Request, res: Response) => {
    const medId = Number(req.params.id);
    const addQty = Number(req.body?.add_quantity ?? 30);
    if (!Number.isInteger(medId) || medId <= 0) {
      res.status(400).json({ error: 'Invalid medication ID.' });
      return;
    }
    if (!Number.isFinite(addQty) || addQty <= 0 || addQty > 365) {
      res.status(400).json({ error: 'Refill quantity must be between 1 and 365.' });
      return;
    }

    const med = db
      .prepare('SELECT id, patient_id, remaining_quantity FROM medications WHERE id = ?')
      .get(medId) as { id: number; patient_id: number; remaining_quantity: number } | undefined;
    if (!med) {
      res.status(404).json({ error: 'Medication not found.' });
      return;
    }

    const nextQty = med.remaining_quantity + Math.floor(addQty);
    db.prepare('UPDATE medications SET remaining_quantity = ? WHERE id = ?').run(nextQty, medId);

    if (!checkRefillWarning(nextQty).isLow) {
      db.prepare(`
        UPDATE caregiver_alerts
        SET status = 'resolved', resolved_at = datetime('now')
        WHERE medication_id = ? AND alert_type = 'refill_low' AND status = 'active'
      `).run(medId);
    }

    broadcastEvent('medication:updated', {
      patientId: med.patient_id,
      medicationId: medId,
      action: 'refilled',
      remaining_quantity: nextQty,
    });
    res.json({ ok: true, remaining_quantity: nextQty });
  });

  // Senior One-Tap Dose Confirmation (Prevents Duplicate Confirmations)
  app.post('/api/doses/confirm', (req: Request, res: Response) => {
    const { patient_id, medication_id, schedule_id, confirmation_time } = req.body ?? {};
    const patientId = Number(patient_id);
    const medicationId = Number(medication_id);
    const scheduleId = Number(schedule_id);

    if (
      !Number.isInteger(patientId) ||
      !Number.isInteger(medicationId) ||
      !Number.isInteger(scheduleId)
    ) {
      res.status(400).json({ error: 'patient_id, medication_id, and schedule_id are required.' });
      return;
    }

    const { todayStr } = parseClientClock(req);
    const confISO =
      typeof confirmation_time === 'string' && confirmation_time
        ? confirmation_time
        : new Date().toISOString();

    try {
      const result = confirmDoseSafely(db, {
        patientId,
        medicationId,
        scheduleId,
        logDate: todayStr,
        confirmationTimeISO: confISO,
        confirmationType: 'senior_tap',
      });

      if (!result.alreadyConfirmed) {
        broadcastEvent('dose:confirmed', {
          patientId,
          medicationId,
          scheduleId,
          logDate: todayStr,
          confirmationTime: confISO,
          remainingQuantity: result.remainingQuantity,
        });
      }

      res.json({
        ok: true,
        alreadyConfirmed: result.alreadyConfirmed,
        log: result.log,
        remaining_quantity: result.remainingQuantity,
      });
    } catch (err) {
      res.status(404).json({ error: err instanceof Error ? err.message : 'Unable to confirm dose.' });
    }
  });

  // Snooze Dose for 15 Minutes
  app.post('/api/doses/snooze', (req: Request, res: Response) => {
    const { patient_id, schedule_id, snooze_minutes } = req.body ?? {};
    const patientId = Number(patient_id);
    const scheduleId = Number(schedule_id);
    const mins = Number(snooze_minutes ?? 15);

    if (!Number.isInteger(patientId) || !Number.isInteger(scheduleId)) {
      res.status(400).json({ error: 'patient_id and schedule_id are required.' });
      return;
    }

    const { todayStr, nowMinutes } = parseClientClock(req);
    const snoozedMinutes = Math.min(23 * 60 + 59, nowMinutes + Math.max(1, Math.min(60, mins)));
    const hh = String(Math.floor(snoozedMinutes / 60)).padStart(2, '0');
    const mm = String(snoozedMinutes % 60).padStart(2, '0');
    const snoozedTimeStr = `${hh}:${mm}`;

    const sched = db
      .prepare('SELECT id FROM dose_schedules WHERE id = ?')
      .get(scheduleId);
    if (!sched) {
      res.status(404).json({ error: 'Schedule not found.' });
      return;
    }

    db.prepare(
      'UPDATE dose_schedules SET snoozed_until_date = ?, snoozed_until_time = ? WHERE id = ?'
    ).run(todayStr, snoozedTimeStr, scheduleId);

    broadcastEvent('dose:snoozed', {
      patientId,
      scheduleId,
      snoozedUntilTime: snoozedTimeStr,
      snoozedUntil12h: formatTime12Hour(snoozedTimeStr),
    });

    res.json({
      ok: true,
      snoozed_until_time: snoozedTimeStr,
      snoozed_until_12h: formatTime12Hour(snoozedTimeStr),
    });
  });

  // Caregiver Retroactive Confirmation ("Already Took It")
  app.post('/api/doses/retroactive', (req: Request, res: Response) => {
    const {
      patient_id,
      medication_id,
      schedule_id,
      reported_taken_time,
      note,
    } = req.body ?? {};

    const patientId = Number(patient_id);
    const medicationId = Number(medication_id);
    const scheduleId = Number(schedule_id);

    if (
      !Number.isInteger(patientId) ||
      !Number.isInteger(medicationId) ||
      !Number.isInteger(scheduleId)
    ) {
      res.status(400).json({ error: 'patient_id, medication_id, and schedule_id are required.' });
      return;
    }

    const { todayStr } = parseClientClock(req);
    const confISO = new Date().toISOString();
    const reportedStr =
      typeof reported_taken_time === 'string' && reported_taken_time.trim()
        ? reported_taken_time.trim().slice(0, 60)
        : 'Reported taken earlier today';

    try {
      const result = confirmDoseSafely(db, {
        patientId,
        medicationId,
        scheduleId,
        logDate: todayStr,
        confirmationTimeISO: confISO,
        confirmationType: 'retroactive',
        reportedTakenTime: reportedStr,
        note: typeof note === 'string' ? note.trim().slice(0, 200) : 'Caregiver retroactive confirmation',
      });

      broadcastEvent('dose:retroactive', {
        patientId,
        medicationId,
        scheduleId,
        logDate: todayStr,
        alreadyConfirmed: result.alreadyConfirmed,
      });

      res.json({
        ok: true,
        alreadyConfirmed: result.alreadyConfirmed,
        log: result.log,
        remaining_quantity: result.remainingQuantity,
      });
    } catch (err) {
      res.status(404).json({ error: err instanceof Error ? err.message : 'Unable to record retroactive dose.' });
    }
  });

  // Caregiver Marks Dose Genuinely Missed
  app.post('/api/doses/miss', (req: Request, res: Response) => {
    const { patient_id, medication_id, schedule_id, note } = req.body ?? {};
    const patientId = Number(patient_id);
    const medicationId = Number(medication_id);
    const scheduleId = Number(schedule_id);

    if (
      !Number.isInteger(patientId) ||
      !Number.isInteger(medicationId) ||
      !Number.isInteger(scheduleId)
    ) {
      res.status(400).json({ error: 'patient_id, medication_id, and schedule_id are required.' });
      return;
    }

    const { todayStr } = parseClientClock(req);
    const sched = db
      .prepare('SELECT scheduled_time FROM dose_schedules WHERE id = ?')
      .get(scheduleId) as { scheduled_time: string } | undefined;
    if (!sched) {
      res.status(404).json({ error: 'Schedule not found.' });
      return;
    }

    const existing = db
      .prepare('SELECT id, status FROM adherence_logs WHERE schedule_id = ? AND log_date = ?')
      .get(scheduleId, todayStr) as { id: number; status: string } | undefined;

    if (existing && (existing.status === 'taken' || existing.status === 'retroactive')) {
      res.status(409).json({ error: 'Dose was already confirmed as taken.' });
      return;
    }

    if (existing) {
      db.prepare(`
        UPDATE adherence_logs
        SET status = 'missed', confirmation_type = 'caregiver_marked_missed', note = ?
        WHERE id = ?
      `).run(String(note ?? 'Confirmed missed by caregiver').slice(0, 200), existing.id);
    } else {
      db.prepare(`
        INSERT INTO adherence_logs (
          patient_id, medication_id, schedule_id, log_date, scheduled_time,
          confirmation_time, reported_taken_time, status, confirmation_type, note
        ) VALUES (?, ?, ?, ?, ?, NULL, NULL, 'missed', 'caregiver_marked_missed', ?)
      `).run(
        patientId,
        medicationId,
        scheduleId,
        todayStr,
        sched.scheduled_time,
        String(note ?? 'Confirmed missed by caregiver').slice(0, 200)
      );
    }

    db.prepare(`
      UPDATE caregiver_alerts
      SET status = 'resolved', resolved_at = datetime('now')
      WHERE schedule_id = ? AND alert_date = ? AND alert_type = 'missed_dose' AND status = 'active'
    `).run(scheduleId, todayStr);

    broadcastEvent('dose:missed', { patientId, medicationId, scheduleId, logDate: todayStr });
    res.json({ ok: true });
  });

  // Resolve an Alert
  app.post('/api/alerts/:id/resolve', (req: Request, res: Response) => {
    const alertId = Number(req.params.id);
    if (!Number.isInteger(alertId) || alertId <= 0) {
      res.status(400).json({ error: 'Invalid alert ID.' });
      return;
    }
    const alert = db
      .prepare('SELECT patient_id FROM caregiver_alerts WHERE id = ?')
      .get(alertId) as { patient_id: number } | undefined;
    if (!alert) {
      res.status(404).json({ error: 'Alert not found.' });
      return;
    }
    db.prepare(
      "UPDATE caregiver_alerts SET status = 'resolved', resolved_at = datetime('now') WHERE id = ?"
    ).run(alertId);

    broadcastEvent('alert:resolved', { patientId: alert.patient_id, alertId });
    res.json({ ok: true });
  });

  // Trigger Escalation Check
  app.post('/api/alerts/check-escalations', (req: Request, res: Response) => {
    const { todayStr, nowMinutes } = parseClientClock(req);
    const created = runMissedDoseEscalations(db, todayStr, nowMinutes);
    if (created > 0) {
      broadcastEvent('alert:created', { count: created });
    }
    res.json({ ok: true, created });
  });

  // Simulate Overdue Dose (>30 mins past scheduled time) for Demonstration
  app.post('/api/demo/simulate-overdue', (req: Request, res: Response) => {
    const patientId = Number(req.body?.patient_id ?? 1);
    const { todayStr, nowMinutes } = parseClientClock(req);

    // Find an unconfirmed schedule for this patient today and shift its schedule_time or create an overdue alert
    const unconfirmed = db
      .prepare(`
        SELECT ds.id AS schedule_id, ds.medication_id, ds.scheduled_time, m.medicine_name, m.dosage
        FROM dose_schedules ds
        JOIN medications m ON m.id = ds.medication_id
        LEFT JOIN adherence_logs al ON al.schedule_id = ds.id AND al.log_date = ?
        WHERE m.patient_id = ? AND ds.active = 1 AND (al.id IS NULL OR al.status = 'pending')
        ORDER BY ds.scheduled_time ASC
        LIMIT 1
      `)
      .get(todayStr, patientId) as
      | {
          schedule_id: number;
          medication_id: number;
          scheduled_time: string;
          medicine_name: string;
          dosage: string;
        }
      | undefined;

    if (!unconfirmed) {
      res.status(400).json({ error: 'All doses for today are already confirmed.' });
      return;
    }

    const overdueTargetMins = Math.max(0, nowMinutes - 42);
    const hh = String(Math.floor(overdueTargetMins / 60)).padStart(2, '0');
    const mm = String(overdueTargetMins % 60).padStart(2, '0');
    const shiftedTime = `${hh}:${mm}`;

    db.prepare('UPDATE dose_schedules SET scheduled_time = ?, snoozed_until_date = NULL, snoozed_until_time = NULL WHERE id = ?').run(
      shiftedTime,
      unconfirmed.schedule_id
    );

    runMissedDoseEscalations(db, todayStr, nowMinutes);
    broadcastEvent('alert:created', { patientId, scheduleId: unconfirmed.schedule_id });
    res.json({
      ok: true,
      medication: `${unconfirmed.medicine_name} ${unconfirmed.dosage}`,
      shifted_scheduled_time: shiftedTime,
    });
  });

  // Reset Sample Demonstration Dataset
  app.post('/api/demo/reset', (req: Request, res: Response) => {
    const { todayStr } = parseClientClock(req);
    resetAndSeedSampleDataset(db, todayStr);
    broadcastEvent('demo:reset', { todayStr });
    res.json({ ok: true });
  });

  // Background Missed-Dose Escalation Timer (runs every 30s on server)
  setInterval(() => {
    try {
      const created = runMissedDoseEscalations(db);
      if (created > 0) {
        broadcastEvent('alert:created', { count: created });
      }
    } catch (err) {
      console.error('Escalation check error:', err);
    }
  }, 30000);

  // Vite Middleware (Dev) or Static Assets (Prod)
  if (!IS_PROD) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'mpa',
    });

    app.get('/caregiver', async (req: Request, res: Response, next) => {
      try {
        const htmlPath = path.resolve(process.cwd(), 'caregiver.html');
        let html = fs.readFileSync(htmlPath, 'utf-8');
        html = await vite.transformIndexHtml(req.originalUrl, html);
        res.status(200).set({ 'Content-Type': 'text/html' }).end(html);
      } catch (e) {
        next(e);
      }
    });

    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir));
    app.get('/caregiver', (_req: Request, res: Response) => {
      res.sendFile(path.join(distDir, 'caregiver.html'));
    });
    app.get('/', (_req: Request, res: Response) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`PillPing: CareCircle running at http://localhost:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
