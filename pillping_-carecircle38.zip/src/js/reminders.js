// Web Worker + Visibility-aware background reminder scheduler

export function createReminderScheduler({ onReminderDue }) {
  let worker = null;
  let fallbackInterval = null;
  let currentSchedules = [];
  const triggeredKeys = new Set();

  function getClock() {
    const now = new Date();
    const y = now.getFullYear();
    const m = String(now.getMonth() + 1).padStart(2, '0');
    const d = String(now.getDate()).padStart(2, '0');
    return {
      dateStr: `${y}-${m}-${d}`,
      minutes: now.getHours() * 60 + now.getMinutes(),
    };
  }

  function parseMinutes(hhmm) {
    const parts = String(hhmm || '').split(':');
    if (parts.length !== 2) return null;
    const h = Number(parts[0]);
    const m = Number(parts[1]);
    return Number.isFinite(h) && Number.isFinite(m) ? h * 60 + m : null;
  }

  function evaluateLocally() {
    const { dateStr, minutes } = getClock();
    for (const dose of currentSchedules) {
      if (!dose || dose.state === 'taken' || dose.state === 'missed') continue;
      const targetTime = dose.snoozed_until_time || dose.scheduled_time;
      const targetMins = parseMinutes(targetTime);
      if (targetMins === null) continue;
      const diff = minutes - targetMins;
      if (diff >= 0 && diff <= 30) {
        const key = `${dateStr}:${dose.schedule_id}:${targetTime}`;
        if (!triggeredKeys.has(key)) {
          triggeredKeys.add(key);
          onReminderDue?.(dose);
        }
      }
    }
  }

  if (typeof Worker !== 'undefined') {
    try {
      worker = new Worker('/reminder-worker.js');
      worker.onmessage = (event) => {
        if (event.data?.type === 'REMINDER_DUE' && event.data.dose) {
          const { dateStr } = getClock();
          const dose = event.data.dose;
          const targetTime = dose.snoozed_until_time || dose.scheduled_time;
          const key = `${dateStr}:${dose.schedule_id}:${targetTime}`;
          if (!triggeredKeys.has(key)) {
            triggeredKeys.add(key);
            onReminderDue?.(dose);
          }
        }
      };
    } catch {
      worker = null;
    }
  }

  if (!worker) {
    fallbackInterval = setInterval(evaluateLocally, 15000);
  }

  // Recalculate reminders immediately when browser tab becomes visible again
  function handleVisibilityChange() {
    if (document.visibilityState === 'visible') {
      if (worker) {
        worker.postMessage({ type: 'CHECK_NOW' });
      } else {
        evaluateLocally();
      }
    }
  }

  document.addEventListener('visibilitychange', handleVisibilityChange);

  return {
    updateSchedules(schedules) {
      currentSchedules = Array.isArray(schedules) ? schedules : [];
      if (worker) {
        worker.postMessage({ type: 'UPDATE_SCHEDULES', schedules: currentSchedules });
      } else {
        evaluateLocally();
      }
    },
    destroy() {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      if (worker) worker.terminate();
      if (fallbackInterval) clearInterval(fallbackInterval);
    },
  };
}
