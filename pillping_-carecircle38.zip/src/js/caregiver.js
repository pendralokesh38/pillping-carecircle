import { renderWeeklyScorecard } from './adherence.js';
import {
  escapeHtml,
  fetchPatientDashboard,
  fetchPatients,
  formatIsoTo12Hour,
  markDoseMissed,
  recordRetroactiveDose,
  resetSampleDataset,
  resolveAlert,
  simulateOverdueDemo,
  subscribeToSyncEvents,
  updatePatientContact,
} from './api.js';
import { createMedicationModalController, renderMedicationTable } from './medications.js';
import { playConfirmationChime, showBrowserNotification } from './notifications.js';

const STORAGE_CG_PATIENT_KEY = 'pillping_caregiver_patient_id';

const state = {
  patients: [],
  activePatientId: Number(localStorage.getItem(STORAGE_CG_PATIENT_KEY)) || 1,
  dashboard: null,
  selectedCalendarDate: null,
  retroDose: null,
};

const els = {
  patientList: document.getElementById('cgPatientList'),
  topbarAvatar: document.getElementById('cgTopbarAvatar'),
  topbarTitle: document.getElementById('cgTopbarTitle'),
  topbarSubtitle: document.getElementById('cgTopbarSubtitle'),
  syncStatus: document.getElementById('cgSyncStatus'),
  addMedBtn: document.getElementById('cgAddMedBtn'),
  alertsList: document.getElementById('cgAlertsList'),
  alertsCountBadge: document.getElementById('cgAlertsCount'),
  todayTableWrap: document.getElementById('cgTodayScheduleWrap'),
  scorecardEl: document.getElementById('cgWeeklyScorecard'),
  calendarEl: document.getElementById('cgComplianceCalendar'),
  dayDetailEl: document.getElementById('cgDayAuditDetail'),
  medTableContainer: document.getElementById('cgMedicationsTableWrap'),
  contactForm: document.getElementById('cgContactForm'),
  contactSaveMsg: document.getElementById('cgContactSaveMsg'),
  simulateOverdueBtn: document.getElementById('cgSimulateOverdueBtn'),
  resetDemoBtn: document.getElementById('cgResetDemoBtn'),
  retroBackdrop: document.getElementById('retroModalBackdrop'),
  retroForm: document.getElementById('retroForm'),
  retroMedSummary: document.getElementById('retroMedSummary'),
  retroCancelBtn: document.getElementById('retroCancelBtn'),
  toast: document.getElementById('cgToast'),
};

let toastTimer = null;
function showToast(message) {
  if (!els.toast) return;
  els.toast.textContent = message;
  els.toast.classList.remove('hidden');
  if (toastTimer) clearTimeout(toastTimer);
  toastTimer = setTimeout(() => {
    els.toast.classList.add('hidden');
  }, 4200);
}

const medModal = createMedicationModalController({
  onSaved: async () => {
    await loadDashboard();
    showToast('Medication schedule saved and synchronized.');
  },
  onError: (msg) => showToast(msg),
});

function renderSidebarPatients() {
  if (!els.patientList) return;
  els.patientList.innerHTML = state.patients
    .map(
      (p) => `
      <button
        type="button"
        class="cg-patient-btn ${p.id === state.activePatientId ? 'is-active' : ''}"
        data-select-patient="${p.id}"
      >
        <img
          class="cg-patient-avatar"
          src="${escapeHtml(p.avatar_url || '/src/assets/images/avatar_patient_robert_1795197357201.jpg')}"
          alt="${escapeHtml(p.name)}"
          referrerPolicy="no-referrer"
        />
        <span>
          <span class="cg-patient-name">${escapeHtml(p.name)}</span>
          <span class="cg-patient-meta">Age ${p.age}${p.is_sample ? ' · Sample' : ''}</span>
        </span>
      </button>
    `
    )
    .join('');

  els.patientList.querySelectorAll('[data-select-patient]').forEach((btn) => {
    btn.addEventListener('click', async () => {
      state.activePatientId = Number(btn.getAttribute('data-select-patient'));
      localStorage.setItem(STORAGE_CG_PATIENT_KEY, String(state.activePatientId));
      state.selectedCalendarDate = null;
      await loadDashboard();
    });
  });
}

function renderTopbar() {
  if (!state.dashboard) return;
  const { patient, caregiver } = state.dashboard;

  if (els.topbarAvatar) {
    els.topbarAvatar.src =
      patient.avatar_url || '/src/assets/images/avatar_patient_robert_1795197357201.jpg';
    els.topbarAvatar.alt = patient.name;
  }
  if (els.topbarTitle) {
    els.topbarTitle.textContent = `${patient.name} — Caregiver Oversight`;
  }
  if (els.topbarSubtitle) {
    const sampleTag = patient.is_sample ? ' · Sample Demonstration Data' : '';
    const cgText = caregiver
      ? `Primary Caregiver: ${caregiver.name} (${caregiver.contact_number})`
      : 'Caregiver not assigned';
    els.topbarSubtitle.textContent = `Age ${patient.age} · ${patient.conditions} · ${cgText}${sampleTag}`;
  }
}

function renderAlertsAndRefills() {
  if (!els.alertsList || !state.dashboard) return;
  const alerts = state.dashboard.alerts || [];
  const doses = state.dashboard.todayDoses || [];

  if (els.alertsCountBadge) {
    els.alertsCountBadge.textContent = `${alerts.length} active`;
  }

  if (alerts.length === 0) {
    els.alertsList.innerHTML = `
      <p class="cg-panel-subtitle">No urgent missed-dose alerts or low-refill warnings right now.</p>
    `;
    return;
  }

  els.alertsList.innerHTML = alerts
    .map((alert) => {
      const isRefill = alert.alert_type === 'refill_low';
      const matchingDose = doses.find((d) => d.schedule_id === alert.schedule_id);
      const overdueText =
        !isRefill && matchingDose && matchingDose.minutes_overdue > 0
          ? `Unconfirmed for ${matchingDose.minutes_overdue} minutes`
          : '';

      return `
        <div class="alert-row ${isRefill ? 'is-refill' : ''}">
          <div>
            <div class="alert-row-title">
              ${isRefill ? 'Refill Warning' : 'Urgent Missed Dose Escalation'}: ${escapeHtml(
        alert.message
      )}
            </div>
            <div class="alert-row-meta">
              ${
                isRefill
                  ? `Remaining inventory: ${alert.remaining_quantity} pills (below 5-dose threshold)`
                  : `Scheduled ${escapeHtml(
                      matchingDose?.scheduled_time_12h || alert.scheduled_time
                    )} · ${escapeHtml(overdueText || 'Past 30-min grace window')}`
              }
            </div>
          </div>
          <div class="alert-row-actions">
            ${
              isRefill
                ? `<button type="button" class="btn-cg btn-cg-primary" data-alert-refill="${alert.medication_id}">
                    Refill +30 Pills
                   </button>`
                : `<button type="button" class="btn-cg btn-cg-green" data-alert-retro="${alert.schedule_id}">
                    Already Took It
                   </button>
                   <button type="button" class="btn-cg btn-cg-danger" data-alert-miss="${alert.schedule_id}">
                    Mark Missed
                   </button>`
            }
            <button type="button" class="btn-cg btn-cg-secondary" data-alert-resolve="${alert.id}">
              Dismiss
            </button>
          </div>
        </div>
      `;
    })
    .join('');

  els.alertsList.querySelectorAll('[data-alert-retro]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const schedId = Number(btn.getAttribute('data-alert-retro'));
      const dose = doses.find((d) => d.schedule_id === schedId);
      if (dose) openRetroactiveModal(dose);
    });
  });

  els.alertsList.querySelectorAll('[data-alert-miss]').forEach((btn) => {
    btn.addEventListener('click', async () => {
      const schedId = Number(btn.getAttribute('data-alert-miss'));
      const dose = doses.find((d) => d.schedule_id === schedId);
      if (!dose) return;
      await markDoseMissed({
        patient_id: state.activePatientId,
        medication_id: dose.medication_id,
        schedule_id: dose.schedule_id,
      });
      await loadDashboard();
      showToast(`${dose.medicine_name} marked as missed.`);
    });
  });

  els.alertsList.querySelectorAll('[data-alert-refill]').forEach((btn) => {
    btn.addEventListener('click', async () => {
      const medId = Number(btn.getAttribute('data-alert-refill'));
      const { refillMedication } = await import('./api.js');
      await refillMedication(medId, 30);
      await loadDashboard();
      showToast('Medication inventory refilled (+30 pills).');
    });
  });

  els.alertsList.querySelectorAll('[data-alert-resolve]').forEach((btn) => {
    btn.addEventListener('click', async () => {
      const alertId = Number(btn.getAttribute('data-alert-resolve'));
      await resolveAlert(alertId);
      await loadDashboard();
    });
  });
}

function renderTodayScheduleTable() {
  if (!els.todayTableWrap || !state.dashboard) return;
  const doses = state.dashboard.todayDoses || [];

  if (doses.length === 0) {
    els.todayTableWrap.innerHTML = `<p class="cg-panel-subtitle">No doses scheduled for today.</p>`;
    return;
  }

  const rowsHtml = doses
    .map((d) => {
      let statusHtml = `<span class="status-label is-muted">Upcoming</span>`;
      let confirmDetail = 'Awaiting scheduled time';

      if (d.state === 'taken') {
        const timeStr = d.log?.confirmation_time
          ? formatIsoTo12Hour(d.log.confirmation_time)
          : '';
        const isRetro = d.log?.confirmation_type === 'retroactive';
        statusHtml = `
          <span class="status-label is-green">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
              <path d="M20 6 9 17l-5-5"></path>
            </svg>
            ${isRetro ? 'Taken (Retroactive)' : 'Taken'}
          </span>
        `;
        confirmDetail = isRetro
          ? `Reported taken: ${escapeHtml(d.log?.reported_taken_time || '')} (logged ${escapeHtml(
              timeStr
            )})`
          : `${escapeHtml(d.medicine_name)} taken at ${escapeHtml(timeStr)}.`;
      } else if (d.state === 'due') {
        statusHtml = `<span class="status-label is-amber">Due Now</span>`;
        confirmDetail = 'Reminder active on Senior screen';
      } else if (d.state === 'snoozed') {
        statusHtml = `<span class="status-label is-amber">Snoozed</span>`;
        confirmDetail = `Snoozed until ${escapeHtml(d.snoozed_until_12h)}`;
      } else if (d.state === 'overdue') {
        statusHtml = `<span class="status-label is-red">Overdue (${d.minutes_overdue}m)</span>`;
        confirmDetail = 'Past 30-min grace period — caregiver alert raised';
      } else if (d.state === 'missed') {
        statusHtml = `<span class="status-label is-red">Missed</span>`;
        confirmDetail = 'Marked missed by caregiver';
      }

      const actionBtn =
        d.state === 'taken' || d.state === 'missed'
          ? `<span class="cg-panel-subtitle">Complete</span>`
          : `<button type="button" class="btn-cg btn-cg-secondary" data-row-retro="${d.schedule_id}">Already Took It</button>`;

      return `
        <tr>
          <td class="font-mono-num">${escapeHtml(d.scheduled_time_12h)}<div class="cg-panel-subtitle">${escapeHtml(
        d.schedule_period
      )}</div></td>
          <td><strong>${escapeHtml(d.medicine_name)} ${escapeHtml(
        d.dosage
      )}</strong><div class="cg-panel-subtitle">${escapeHtml(d.instructions)}</div></td>
          <td>${statusHtml}</td>
          <td>${confirmDetail}</td>
          <td>${actionBtn}</td>
        </tr>
      `;
    })
    .join('');

  els.todayTableWrap.innerHTML = `
    <div class="cg-table-wrap">
      <table class="cg-table">
        <thead>
          <tr>
            <th>Time</th>
            <th>Medication</th>
            <th>Status</th>
            <th>Confirmation Log</th>
            <th>Caregiver Action</th>
          </tr>
        </thead>
        <tbody>${rowsHtml}</tbody>
      </table>
    </div>
  `;

  els.todayTableWrap.querySelectorAll('[data-row-retro]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const schedId = Number(btn.getAttribute('data-row-retro'));
      const dose = doses.find((d) => d.schedule_id === schedId);
      if (dose) openRetroactiveModal(dose);
    });
  });
}

function openRetroactiveModal(dose) {
  state.retroDose = dose;
  if (els.retroMedSummary) {
    els.retroMedSummary.textContent = `${dose.medicine_name} ${dose.dosage} — Scheduled for ${dose.scheduled_time_12h}`;
  }
  if (els.retroForm) {
    els.retroForm.elements.reported_taken_time.value = dose.scheduled_time_12h;
    els.retroForm.elements.note.value = 'Confirmed via phone check-in with patient';
  }
  els.retroBackdrop?.classList.remove('hidden');
}

function closeRetroactiveModal() {
  state.retroDose = null;
  els.retroBackdrop?.classList.add('hidden');
}

function populateContactForm() {
  if (!els.contactForm || !state.dashboard) return;
  const { patient, caregiver } = state.dashboard;
  els.contactForm.elements.preferred_greeting.value = patient.preferred_greeting || '';
  els.contactForm.elements.caregiver_name.value = caregiver?.name || '';
  els.contactForm.elements.caregiver_phone.value = caregiver?.contact_number || '';
  els.contactForm.elements.caregiver_email.value = caregiver?.email || '';
  els.contactForm.elements.caregiver_relationship.value = caregiver?.relationship || '';
}

function renderDashboard() {
  if (!state.dashboard) return;
  renderSidebarPatients();
  renderTopbar();
  renderAlertsAndRefills();
  renderTodayScheduleTable();

  if (!state.selectedCalendarDate) {
    state.selectedCalendarDate = state.dashboard.today;
  }

  renderWeeklyScorecard({
    scorecardEl: els.scorecardEl,
    calendarEl: els.calendarEl,
    dayDetailEl: els.dayDetailEl,
    weeklyStats: state.dashboard.weeklyStats,
    calendarDays: state.dashboard.calendar14Days || state.dashboard.weeklyCalendar,
    historicalLogs: state.dashboard.historicalLogs || [],
    todayDoses: state.dashboard.todayDoses || [],
    todayStr: state.dashboard.today,
    selectedDate: state.selectedCalendarDate,
    onSelectDate: (dateStr) => {
      state.selectedCalendarDate = dateStr;
      renderDashboard();
    },
  });

  renderMedicationTable({
    containerEl: els.medTableContainer,
    medications: state.dashboard.medications || [],
    onEdit: (med) => medModal.open({ patientId: state.activePatientId, medication: med }),
    onDelete: async () => {
      await loadDashboard();
      showToast('Medication removed.');
    },
    onRefill: async () => {
      await loadDashboard();
      showToast('Inventory updated (+30 pills).');
    },
  });

  populateContactForm();
}

async function loadDashboard() {
  try {
    const [patientsRes, dashRes] = await Promise.all([
      fetchPatients(),
      fetchPatientDashboard(state.activePatientId),
    ]);
    state.patients = patientsRes.patients || [];
    state.dashboard = dashRes;
    renderDashboard();
  } catch (err) {
    showToast(err instanceof Error ? err.message : 'Unable to refresh dashboard.');
  }
}

async function init() {
  try {
    const { patients } = await fetchPatients();
    state.patients = patients || [];
    if (!state.patients.some((p) => p.id === state.activePatientId) && state.patients[0]) {
      state.activePatientId = state.patients[0].id;
    }
    await loadDashboard();
  } catch (err) {
    showToast(err instanceof Error ? err.message : 'Failed to connect to Caregiver API.');
  }

  els.addMedBtn?.addEventListener('click', () => {
    medModal.open({ patientId: state.activePatientId, medication: null });
  });

  els.retroCancelBtn?.addEventListener('click', closeRetroactiveModal);

  els.retroForm?.addEventListener('submit', async (e) => {
    e.preventDefault();
    if (!state.retroDose) return;
    try {
      await recordRetroactiveDose({
        patient_id: state.activePatientId,
        medication_id: state.retroDose.medication_id,
        schedule_id: state.retroDose.schedule_id,
        reported_taken_time: els.retroForm.elements.reported_taken_time.value.trim(),
        note: els.retroForm.elements.note.value.trim(),
      });
      closeRetroactiveModal();
      await loadDashboard();
      showToast('Retroactive confirmation recorded with separate audit timestamps.');
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'Unable to save retroactive confirmation.');
    }
  });

  els.contactForm?.addEventListener('submit', async (e) => {
    e.preventDefault();
    if (els.contactSaveMsg) els.contactSaveMsg.textContent = '';
    try {
      await updatePatientContact(state.activePatientId, {
        preferred_greeting: els.contactForm.elements.preferred_greeting.value.trim(),
        caregiver_name: els.contactForm.elements.caregiver_name.value.trim(),
        caregiver_phone: els.contactForm.elements.caregiver_phone.value.trim(),
        caregiver_email: els.contactForm.elements.caregiver_email.value.trim(),
        caregiver_relationship: els.contactForm.elements.caregiver_relationship.value.trim(),
      });
      await loadDashboard();
      if (els.contactSaveMsg) {
        els.contactSaveMsg.textContent = 'Emergency SOS contact updated and synced.';
      }
    } catch (err) {
      if (els.contactSaveMsg) {
        els.contactSaveMsg.textContent = err instanceof Error ? err.message : 'Save failed.';
      }
    }
  });

  els.simulateOverdueBtn?.addEventListener('click', async () => {
    try {
      const res = await simulateOverdueDemo(state.activePatientId);
      await loadDashboard();
      showToast(`Simulated 42-min overdue escalation for ${res.medication}.`);
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'Could not simulate overdue dose.');
    }
  });

  els.resetDemoBtn?.addEventListener('click', async () => {
    await resetSampleDataset();
    state.selectedCalendarDate = null;
    await loadDashboard();
    showToast('Sample 2-patient 14-day demonstration dataset restored.');
  });

  // Real-Time SSE Synchronization
  subscribeToSyncEvents({
    onStatusChange: (status) => {
      if (!els.syncStatus) return;
      if (status === 'connected') {
        els.syncStatus.classList.remove('is-reconnecting');
        els.syncStatus.innerHTML = `<span class="sync-dot" aria-hidden="true"></span> Live Sync Active`;
      } else {
        els.syncStatus.classList.add('is-reconnecting');
        els.syncStatus.innerHTML = `<span class="sync-dot" aria-hidden="true"></span> Reconnecting...`;
      }
    },
    onEvent: async (eventType, payload) => {
      if (eventType === 'connected') return;
      await loadDashboard();

      if (eventType === 'dose:confirmed' && Number(payload.patientId) === state.activePatientId) {
        playConfirmationChime();
        const confirmedAt = formatIsoTo12Hour(payload.confirmationTime);
        showToast(`Dose confirmed by patient at ${confirmedAt}!`);
      } else if (eventType === 'alert:created') {
        showBrowserNotification(
          'PillPing Urgent Caregiver Alert',
          'A scheduled medication is unconfirmed past the 30-minute grace window.'
        );
        showToast('New missed-dose escalation alert generated.');
      }
    },
  });
}

init();
