// REST API client and real-time Server-Sent Events (SSE) synchronization

export function getClientClock() {
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const d = String(now.getDate()).padStart(2, '0');
  const hh = String(now.getHours()).padStart(2, '0');
  const mm = String(now.getMinutes()).padStart(2, '0');
  return {
    date: `${y}-${m}-${d}`,
    time: `${hh}:${mm}`,
  };
}

export function escapeHtml(str) {
  return String(str ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

export function formatIsoTo12Hour(isoString) {
  if (!isoString) return '';
  const dt = new Date(isoString);
  if (Number.isNaN(dt.getTime())) return isoString;
  return dt.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
}

async function requestJson(url, options = {}) {
  const response = await fetch(url, {
    headers: {
      'Content-Type': 'application/json',
      ...(options.headers || {}),
    },
    ...options,
  });

  const contentType = response.headers.get('content-type') || '';
  const payload = contentType.includes('application/json')
    ? await response.json()
    : { error: await response.text() };

  if (!response.ok) {
    throw new Error(payload?.error || `Request failed (${response.status})`);
  }
  return payload;
}

export async function fetchPatients() {
  return requestJson('/api/patients');
}

export async function fetchPatientDashboard(patientId) {
  const clock = getClientClock();
  const params = new URLSearchParams({ date: clock.date, time: clock.time });
  return requestJson(`/api/patients/${patientId}/dashboard?${params.toString()}`);
}

export async function confirmDose(payload) {
  const clock = getClientClock();
  return requestJson('/api/doses/confirm', {
    method: 'POST',
    body: JSON.stringify({
      ...payload,
      log_date: clock.date,
      current_time: clock.time,
      confirmation_time: new Date().toISOString(),
    }),
  });
}

export async function snoozeDose(payload) {
  const clock = getClientClock();
  return requestJson('/api/doses/snooze', {
    method: 'POST',
    body: JSON.stringify({
      ...payload,
      log_date: clock.date,
      current_time: clock.time,
      snooze_minutes: payload.snooze_minutes ?? 15,
    }),
  });
}

export async function recordRetroactiveDose(payload) {
  const clock = getClientClock();
  return requestJson('/api/doses/retroactive', {
    method: 'POST',
    body: JSON.stringify({
      ...payload,
      log_date: clock.date,
      current_time: clock.time,
    }),
  });
}

export async function markDoseMissed(payload) {
  const clock = getClientClock();
  return requestJson('/api/doses/miss', {
    method: 'POST',
    body: JSON.stringify({
      ...payload,
      log_date: clock.date,
      current_time: clock.time,
    }),
  });
}

export async function createMedication(payload) {
  return requestJson('/api/medications', {
    method: 'POST',
    body: JSON.stringify(payload),
  });
}

export async function updateMedication(medId, payload) {
  return requestJson(`/api/medications/${medId}`, {
    method: 'PUT',
    body: JSON.stringify(payload),
  });
}

export async function deleteMedication(medId) {
  return requestJson(`/api/medications/${medId}`, {
    method: 'DELETE',
  });
}

export async function refillMedication(medId, addQuantity = 30) {
  return requestJson(`/api/medications/${medId}/refill`, {
    method: 'POST',
    body: JSON.stringify({ add_quantity: addQuantity }),
  });
}

export async function updatePatientContact(patientId, payload) {
  return requestJson(`/api/patients/${patientId}/contact`, {
    method: 'PUT',
    body: JSON.stringify(payload),
  });
}

export async function resolveAlert(alertId) {
  return requestJson(`/api/alerts/${alertId}/resolve`, {
    method: 'POST',
  });
}

export async function simulateOverdueDemo(patientId) {
  const clock = getClientClock();
  return requestJson('/api/demo/simulate-overdue', {
    method: 'POST',
    body: JSON.stringify({
      patient_id: patientId,
      log_date: clock.date,
      current_time: clock.time,
    }),
  });
}

export async function resetSampleDataset() {
  const clock = getClientClock();
  return requestJson('/api/demo/reset', {
    method: 'POST',
    body: JSON.stringify({ log_date: clock.date }),
  });
}

export function subscribeToSyncEvents({ onEvent, onStatusChange }) {
  let source = null;
  let reconnectTimer = null;
  let closed = false;

  const eventNames = [
    'connected',
    'dose:confirmed',
    'dose:snoozed',
    'dose:retroactive',
    'dose:missed',
    'medication:updated',
    'alert:created',
    'alert:resolved',
    'patient:updated',
    'demo:reset',
  ];

  function connect() {
    if (closed) return;
    if (source) {
      source.close();
    }
    source = new EventSource('/api/events');

    source.onopen = () => {
      onStatusChange?.('connected');
    };

    source.onerror = () => {
      onStatusChange?.('reconnecting');
      source?.close();
      if (!closed && !reconnectTimer) {
        reconnectTimer = setTimeout(() => {
          reconnectTimer = null;
          connect();
        }, 3000);
      }
    };

    for (const evtName of eventNames) {
      source.addEventListener(evtName, (event) => {
        try {
          const parsed = JSON.parse(event.data || '{}');
          onEvent?.(evtName, parsed);
        } catch {
          onEvent?.(evtName, {});
        }
      });
    }
  }

  connect();

  return () => {
    closed = true;
    if (reconnectTimer) clearTimeout(reconnectTimer);
    source?.close();
  };
}
