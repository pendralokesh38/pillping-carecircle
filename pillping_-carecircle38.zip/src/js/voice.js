// Web Speech API Voice Read-Aloud module with multi-language support and graceful fallbacks

export const SUPPORTED_LANGUAGES = [
  { code: 'en-US', label: 'English (US)' },
  { code: 'es-ES', label: 'Español (Spanish)' },
  { code: 'hi-IN', label: 'हिन्दी (Hindi)' },
  { code: 'fr-FR', label: 'Français (French)' },
  { code: 'zh-CN', label: '中文 (Mandarin)' },
];

const PROMPT_TEMPLATES = {
  'en-US': (d) =>
    `Medication reminder for ${d.scheduled_time_12h}. Please take ${d.medicine_name} ${d.dosage}${
      d.purpose_label ? `, your ${d.purpose_label}` : ''
    }. Instructions: ${d.instructions}. When finished, tap I Took My Medicine.`,
  'es-ES': (d) =>
    `Recordatorio de medicamento para las ${d.scheduled_time_12h}. Por favor tome ${d.medicine_name} ${d.dosage}. Instrucciones: ${d.instructions}. Al terminar, toque el botón verde.`,
  'hi-IN': (d) =>
    `${d.scheduled_time_12h} की दवा का समय हो गया है। कृपया ${d.medicine_name} ${d.dosage} लें। निर्देश: ${d.instructions}। दवा लेने के बाद हरा बटन दबाएं।`,
  'fr-FR': (d) =>
    `Rappel de médicament pour ${d.scheduled_time_12h}. Veuillez prendre ${d.medicine_name} ${d.dosage}. Instructions : ${d.instructions}. Appuyez ensuite sur le bouton vert.`,
  'zh-CN': (d) =>
    `${d.scheduled_time_12h} 用药提醒。请服用 ${d.medicine_name} ${d.dosage}。说明：${d.instructions}。服药后请点击绿色确认按钮。`,
};

export function isSpeechSupported() {
  return typeof window !== 'undefined' && 'speechSynthesis' in window;
}

export function stopSpeaking() {
  if (isSpeechSupported()) {
    window.speechSynthesis.cancel();
  }
}

export function speakDoseInstructions(dose, languageCode = 'en-US') {
  if (!isSpeechSupported()) {
    return {
      ok: false,
      message: 'Voice read-aloud is not supported in this browser.',
    };
  }

  try {
    window.speechSynthesis.cancel();
    const builder = PROMPT_TEMPLATES[languageCode] || PROMPT_TEMPLATES['en-US'];
    const text = builder(dose);
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = languageCode;
    utterance.rate = 0.88; // Slightly slower, clearer pace for elderly listeners
    utterance.pitch = 1.0;

    const voices = window.speechSynthesis.getVoices();
    const langPrefix = languageCode.split('-')[0].toLowerCase();
    const matchingVoice =
      voices.find((v) => v.lang.toLowerCase() === languageCode.toLowerCase()) ||
      voices.find((v) => v.lang.toLowerCase().startsWith(langPrefix));

    if (matchingVoice) {
      utterance.voice = matchingVoice;
    }

    window.speechSynthesis.speak(utterance);

    return {
      ok: true,
      fallbackNotice:
        !matchingVoice && voices.length > 0
          ? `No dedicated ${languageCode} voice found on this device; using default system voice.`
          : '',
    };
  } catch {
    return {
      ok: false,
      message: 'Unable to play voice instructions right now.',
    };
  }
}
