import {
  confirmDose,
  escapeHtml,
  fetchPatientDashboard,
  fetchPatients,
  formatIsoTo12Hour,
  snoozeDose,
  subscribeToSyncEvents,
} from './api.js';
import {
  getNotificationSupportStatus,
  playConfirmationChime,
  playReminderChime,
  requestNotificationPermission,
  showBrowserNotification,
} from './notifications.js';
import { createReminderScheduler } from './reminders.js';
import {
  SUPPORTED_LANGUAGES,
  isSpeechSupported,
  speakDoseInstructions,
  stopSpeaking,
} from './voice.js';

const STORAGE_PATIENT_KEY = 'pillping_senior_patient_id';
const STORAGE_LANG_KEY = 'pillping_voice_language';

const state = {
  patients: [],
  activePatientId: Number(localStorage.getItem(STORAGE_PATIENT_KEY)) || 1,
  language: localStorage.getItem(STORAGE_LANG_KEY) || 'en-US',
  periodFilter: 'All',
  dashboard: null,
  activeReminderDose: null,
  confirmedDoseInfo: null,
  sosOpen: false,
  isSubmitting: false,
};

const els = {
  patientSelect: document.getElementById('seniorPatientSelect'),
  languageSelect: document.getElementById('seniorLanguageSelect'),
  greetingHeading: document.getElementById('seniorGreetingHeading'),
  greetingSubline: document.getElementById('seniorGreetingSubline'),
  clockTime: document.getElementById('seniorClockTime'),
  clockDate: document.getElementById('seniorClockDate'),
  notifStrip: document.getElementById('notifPermissionStrip'),
  notifStatusText: document.getElementById('notifStatusText'),
  enableNotifBtn: document.getElementById('enableNotificationsBtn'),
  testChimeBtn: document.getElementById('testChimeBtn'),
  spotlightCard: document.getElementById('seniorSpotlightCard'),
  doseGrid: document.getElementById('seniorDoseGrid'),
  periodFilters: document.getElementById('seniorPeriodFilters'),
  sosHeaderBtn: document.getElementById('seniorSosBtn'),
  demoTriggerBtn: document.getElementById('demoTriggerAmlodipineBtn'),
  overlay: document.getElementById('reminderOverlay'),
  overlayCard: document.getElementById('reminderModalCard'),
  toast: document.getElementById('seniorToast'),
};

let toastTimer = null;
function showToast(message) {
  if (!els.toast) return;
  els.toast.textContent = message;
  els.toast.classList.remove('hidden');
  if (toastTimer) clearTimeout(toastTimer);
  toastTimer = setTimeout(() => {
    els.toast.classList.add('hidden');
  }, 4000);
}

function updateLiveClock() {
  const now = new Date();
  if (els.clockTime) {
    els.clockTime.textContent = now.toLocaleTimeString([], {
      hour: 'numeric',
      minute: '2-digit',
    });
  }
  if (els.clockDate) {
    els.clockDate.textContent = now.toLocaleDateString([], {
      weekday: 'long',
      month: 'long',
      day: 'numeric',
    });
  }
}

function updateNotificationBanner() {
  if (!els.notifStatusText || !els.enableNotifBtn) return;
  const status = getNotificationSupportStatus();
  if (status === 'granted') {
    els.notifStatusText.textContent =
      'Browser alerts and audible chimes are enabled while this tab remains open. (Browsers pause timers if the tab or browser is completely closed.)';
    els.enableNotifBtn.classList.add('hidden');
  } else if (status === 'denied') {
    els.notifStatusText.textContent =
      'Browser pop-up notifications are blocked in browser settings. On-screen full-screen alerts and audible chimes will still appear while this tab is open.';
    els.enableNotifBtn.classList.add('hidden');
  } else if (status === 'unsupported') {
    els.notifStatusText.textContent =
      'This browser does not support pop-up notifications. Keep this tab open for on-screen full-screen reminders and audible chimes.';
    els.enableNotifBtn.classList.add('hidden');
  } else {
    els.notifStatusText.textContent =
      'Tap Enable Alerts to allow reminder chimes and pop-ups while this tab is open. Browsers cannot run timers after a tab is completely closed.';
    els.enableNotifBtn.classList.remove('hidden');
  }
}

function renderSelectors() {
  if (els.patientSelect && state.patients.length > 0) {
    els.patientSelect.innerHTML = state.patients
      .map(
        (p) =>
          `<option value="${p.id}" ${p.id === state.activePatientId ? 'selected' : ''}>${escapeHtml(
            p.name
          )}${p.is_sample ? ' (Sample)' : ''}</option>`
      )
      .join('');
  }

  if (els.languageSelect) {
    els.languageSelect.innerHTML = SUPPORTED_LANGUAGES.map(
      (lang) =>
        `<option value="${lang.code}" ${lang.code === state.language ? 'selected' : ''}>${escapeHtml(
          lang.label
        )}</option>`
    ).join('');
  }
}

function getPillSvg(colorName) {
  return `
    <span class="pill-swatch pill-color-${escapeHtml(colorName || 'blue')}" aria-hidden="true">
      <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
        <path d="m10.5 20.5 10-10a4.95 4.95 0 1 0-7-7l-10 10a4.95 4.95 0 1 0 7 7Z"></path>
        <path d="m8.5 8.5 7 7"></path>
      </svg>
    </span>
  `;
}

function getBottleVisualHtml(dose, large = false) {
  if (dose.bottle_image) {
    return `<img src="${escapeHtml(dose.bottle_image)}" alt="${escapeHtml(
      dose.medicine_name
    )} pill bottle" referrerPolicy="no-referrer" />`;
  }
  return `
    <div style="display:flex;flex-direction:column;align-items:center;justify-content:center;gap:8px;padding:12px;">
      ${getPillSvg(dose.pill_color)}
      <strong style="font-size:${large ? '1.125rem' : '0.95rem'};color:var(--text-primary);">${escapeHtml(
    dose.medicine_name
  )}</strong>
      <span style="font-size:0.875rem;color:var(--text-secondary);">No bottle photo uploaded</span>
    </div>
  `;
}

function renderSpotlight() {
  if (!els.spotlightCard || !state.dashboard) return;
  const doses = state.dashboard.todayDoses || [];

  const overdueDose = doses.find((d) => d.state === 'overdue');
  const dueDose = doses.find((d) => d.state === 'due');
  const snoozedDose = doses.find((d) => d.state === 'snoozed');
  const upcomingDose = doses.find((d) => d.state === 'upcoming');
  const nextDose = overdueDose || dueDose || snoozedDose || upcomingDose;

  els.spotlightCard.className = 'spotlight-card';

  if (!nextDose) {
    els.spotlightCard.classList.add('is-complete');
    const takenCount = doses.filter((d) => d.state === 'taken').length;
    els.spotlightCard.innerHTML = `
      <div>
        <p class="spotlight-kicker">All Caught Up</p>
        <h2 class="spotlight-title">Every scheduled medication for today is complete.</h2>
        <p class="spotlight-meta tabular-nums">${takenCount} of ${doses.length} doses confirmed today. Great job!</p>
      </div>
      <div class="spotlight-actions">
        <a href="/caregiver.html" class="btn-senior btn-outline-senior">Open Caregiver Portal</a>
      </div>
    `;
    return;
  }

  let kicker = `Next Scheduled · ${nextDose.schedule_period}`;
  if (nextDose.state === 'due') {
    els.spotlightCard.classList.add('is-due');
    kicker = `Time to Take Now · ${nextDose.scheduled_time_12h}`;
  } else if (nextDose.state === 'overdue') {
    els.spotlightCard.classList.add('is-overdue');
    kicker = `Overdue Reminder · ${nextDose.minutes_overdue} mins past ${nextDose.scheduled_time_12h}`;
  } else if (nextDose.state === 'snoozed') {
    els.spotlightCard.classList.add('is-due');
    kicker = `Snoozed Until ${nextDose.snoozed_until_12h}`;
  }

  const labelTitle = nextDose.purpose_label
    ? `${nextDose.scheduled_time_12h} - ${nextDose.purpose_label} (${nextDose.medicine_name} ${nextDose.dosage})`
    : `${nextDose.scheduled_time_12h} - ${nextDose.medicine_name} ${nextDose.dosage}`;

  els.spotlightCard.innerHTML = `
    <div>
      <p class="spotlight-kicker">${escapeHtml(kicker)}</p>
      <h2 class="spotlight-title">${escapeHtml(labelTitle)}</h2>
      <p class="spotlight-meta">${escapeHtml(nextDose.instructions)} · ${nextDose.remaining_quantity} pills remaining</p>
      <div class="spotlight-actions">
        <button type="button" class="btn-senior btn-take" data-open-reminder="${nextDose.schedule_id}">
          Open Reminder &amp; Confirm
        </button>
        <button type="button" class="btn-senior btn-outline-senior" data-speak-dose="${nextDose.schedule_id}">
          Read Aloud
        </button>
      </div>
    </div>
    <div class="spotlight-photo-box">
      ${getBottleVisualHtml(nextDose, false)}
    </div>
  `;

  els.spotlightCard.querySelector('[data-open-reminder]')?.addEventListener('click', () => {
    openReminderScreen(nextDose, true);
  });

  els.spotlightCard.querySelector('[data-speak-dose]')?.addEventListener('click', () => {
    handleSpeakDose(nextDose);
  });
}

function renderDoseGrid() {
  if (!els.doseGrid || !state.dashboard) return;
  const doses = state.dashboard.todayDoses || [];
  const filtered =
    state.periodFilter === 'All'
      ? doses
      : doses.filter((d) => d.schedule_period === state.periodFilter);

  if (filtered.length === 0) {
    els.doseGrid.innerHTML = `
      <div class="dose-card">
        <h3 class="dose-med-title">No medications in ${escapeHtml(state.periodFilter)}</h3>
        <p class="dose-med-dosage">Select "All" above to view your full daily schedule.</p>
      </div>
    `;
    return;
  }

  els.doseGrid.innerHTML = filtered
    .map((dose) => {
      const stateClass = `state-${dose.state}`;
      let statusLabel = 'Upcoming';
      if (dose.state === 'taken') {
        const timeStr = dose.log?.confirmation_time
          ? formatIsoTo12Hour(dose.log.confirmation_time)
          : '';
        statusLabel = timeStr ? `Taken at ${timeStr}` : 'Taken';
      } else if (dose.state === 'due') {
        statusLabel = 'Due Now';
      } else if (dose.state === 'overdue') {
        statusLabel = `Overdue (${dose.minutes_overdue}m)`;
      } else if (dose.state === 'snoozed') {
        statusLabel = `Snoozed to ${dose.snoozed_until_12h}`;
      } else if (dose.state === 'missed') {
        statusLabel = 'Marked Missed';
      }

      const isDone = dose.state === 'taken' || dose.state === 'missed';

      return `
        <article class="dose-card ${stateClass}" aria-label="${escapeHtml(dose.medicine_name)} at ${escapeHtml(
        dose.scheduled_time_12h
      )}">
          <div>
            <div class="dose-card-top">
              <span class="dose-time-label">${escapeHtml(dose.scheduled_time_12h)} · ${escapeHtml(
        dose.schedule_period
      )}</span>
              <span class="dose-status-text ${escapeHtml(dose.state)}">${escapeHtml(statusLabel)}</span>
            </div>

            <div class="dose-med-row" style="margin-top: 14px;">
              ${getPillSvg(dose.pill_color)}
              <div>
                <h3 class="dose-med-title">${escapeHtml(dose.medicine_name)} ${escapeHtml(dose.dosage)}</h3>
                <div class="dose-med-dosage">${escapeHtml(dose.purpose_label || 'Daily Medication')}</div>
              </div>
            </div>

            <div class="dose-instructions" style="margin-top: 14px;">
              ${escapeHtml(dose.instructions)}
            </div>

            <div class="dose-card-meta" style="margin-top: 12px;">
              <span class="tabular-nums">${dose.remaining_quantity} pills left</span>
              <span>${dose.bottle_image ? 'Bottle photo attached' : 'Color-coded pill'}</span>
            </div>
          </div>

          <div class="dose-card-actions">
            ${
              isDone
                ? `<button type="button" class="btn-senior btn-outline-senior" disabled aria-disabled="true">
                    ${dose.state === 'taken' ? 'Confirmed' : 'Closed'}
                   </button>`
                : `<button type="button" class="btn-senior btn-take" data-card-remind="${dose.schedule_id}">
                    Take Now
                   </button>`
            }
            <button type="button" class="btn-senior btn-outline-senior" data-card-speak="${dose.schedule_id}">
              Read Aloud
            </button>
          </div>
        </article>
      `;
    })
    .join('');

  els.doseGrid.querySelectorAll('[data-card-remind]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const id = Number(btn.getAttribute('data-card-remind'));
      const dose = doses.find((d) => d.schedule_id === id);
      if (dose) openReminderScreen(dose, true);
    });
  });

  els.doseGrid.querySelectorAll('[data-card-speak]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const id = Number(btn.getAttribute('data-card-speak'));
      const dose = doses.find((d) => d.schedule_id === id);
      if (dose) handleSpeakDose(dose);
    });
  });
}

function renderDashboard() {
  if (!state.dashboard) return;
  const { patient, caregiver } = state.dashboard;

  const hour = new Date().getHours();
  const timeOfDay = hour < 12 ? 'Morning' : hour < 17 ? 'Afternoon' : 'Evening';

  if (els.greetingHeading) {
    els.greetingHeading.textContent = `Good ${timeOfDay}, ${patient.name}`;
  }
  if (els.greetingSubline) {
    const cgText = caregiver
      ? `Caregiver: ${caregiver.name} (${caregiver.contact_number})`
      : 'No emergency caregiver configured';
    const sampleNote = patient.is_sample ? ' · Sample Demonstration Profile' : '';
    els.greetingSubline.textContent = `${cgText}${sampleNote}`;
  }

  renderSpotlight();
  renderDoseGrid();
  renderOverlay();
}

function handleSpeakDose(dose) {
  const result = speakDoseInstructions(dose, state.language);
  if (!result.ok) {
    showToast(result.message);
  } else if (result.fallbackNotice) {
    showToast(result.fallbackNotice);
  }
}

function openReminderScreen(dose, playSound = true) {
  state.confirmedDoseInfo = null;
  state.sosOpen = false;
  state.activeReminderDose = dose;

  if (playSound) {
    playReminderChime();
    showBrowserNotification(
      `PillPing Reminder: ${dose.medicine_name} ${dose.dosage}`,
      `${dose.scheduled_time_12h} — ${dose.instructions}`
    );
  }
  renderOverlay();
}

function closeOverlay() {
  stopSpeaking();
  state.activeReminderDose = null;
  state.confirmedDoseInfo = null;
  state.sosOpen = false;
  renderOverlay();
}

function renderOverlay() {
  if (!els.overlay || !els.overlayCard) return;

  if (state.sosOpen) {
    const caregiver = state.dashboard?.caregiver;
    const phone = caregiver?.contact_number || '';
    const caregiverName = caregiver?.name || 'Designated Caregiver';
    const relationship = caregiver?.relationship || 'Emergency Contact';

    els.overlayCard.className = 'reminder-modal-card is-sos';
    els.overlayCard.innerHTML = `
      <div class="reminder-header-line">
        <span class="reminder-time-big" style="color: var(--status-red);">Emergency SOS Quick Dial</span>
      </div>
      <h2 class="reminder-med-headline">Call ${escapeHtml(caregiverName)}?</h2>
      <p class="reminder-guide-copy" style="font-size: 1.375rem;">
        ${escapeHtml(relationship)}<br/>
        <strong class="font-mono-num" style="font-size: 1.75rem; color: var(--text-primary);">${escapeHtml(
          phone || 'No phone number configured in Caregiver Portal'
        )}</strong>
      </p>
      <div class="reminder-primary-actions">
        ${
          phone
            ? `<a href="tel:${escapeHtml(phone)}" class="btn-senior btn-sos" id="confirmSosDialLink">
                Call Caregiver Now
               </a>`
            : `<a href="/caregiver.html" class="btn-senior btn-primary-senior">
                Set Emergency Number
               </a>`
        }
        <button type="button" class="btn-senior btn-outline-senior" id="cancelSosBtn">
          Cancel — Go Back
        </button>
      </div>
    `;
    els.overlay.classList.remove('hidden');
    document.getElementById('cancelSosBtn')?.addEventListener('click', closeOverlay);
    return;
  }

  if (state.confirmedDoseInfo) {
    const info = state.confirmedDoseInfo;
    const greetingName = state.dashboard?.patient?.preferred_greeting || 'Friend';
    const timeFormatted = formatIsoTo12Hour(info.confirmationTime);

    els.overlayCard.className = 'reminder-modal-card is-confirmation';
    els.overlayCard.innerHTML = `
      <div class="confirmation-check-circle" aria-hidden="true">
        <svg width="52" height="52" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round">
          <path d="M20 6 9 17l-5-5"></path>
        </svg>
      </div>
      <h2 class="confirmation-headline">Good Job, ${escapeHtml(greetingName)}!</h2>
      <p class="confirmation-detail">
        ${escapeHtml(info.dose.medicine_name)} ${escapeHtml(info.dose.dosage)} recorded at
        <span class="font-mono-num">${escapeHtml(timeFormatted)}</span>.
      </p>
      <p class="reminder-guide-copy">
        Your Caregiver Dashboard has been updated automatically. Remaining pills:
        <strong class="tabular-nums">${info.remainingQuantity}</strong>.
      </p>
      <button type="button" class="btn-senior btn-take" id="closeConfirmationBtn" style="min-width: 280px;">
        Back to Today's Schedule
      </button>
    `;
    els.overlay.classList.remove('hidden');
    document.getElementById('closeConfirmationBtn')?.addEventListener('click', closeOverlay);
    return;
  }

  if (state.activeReminderDose) {
    const dose = state.activeReminderDose;
    const headline = dose.purpose_label
      ? `${dose.purpose_label} (${dose.medicine_name} ${dose.dosage})`
      : `${dose.medicine_name} ${dose.dosage}`;

    els.overlayCard.className = 'reminder-modal-card';
    els.overlayCard.innerHTML = `
      <div class="reminder-header-line">
        <span class="reminder-time-big">${escapeHtml(dose.scheduled_time_12h)} — ${escapeHtml(
      dose.schedule_period
    )} Dose</span>
        <button type="button" class="btn-senior btn-outline-senior" id="closeReminderXBtn" style="min-height: 52px; padding: 8px 18px; font-size: 1rem;">
          Close
        </button>
      </div>

      <div class="reminder-body-grid">
        <div>
          <h2 class="reminder-med-headline">${escapeHtml(headline)}</h2>
          <div class="reminder-instruction-box">
            ${escapeHtml(dose.instructions)}
          </div>
          <p class="reminder-guide-copy">
            Check the bottle photo on the right to match your medicine. Once you swallow your pill, tap the large green button below.
          </p>
        </div>
        <div class="reminder-bottle-frame">
          ${getBottleVisualHtml(dose, true)}
        </div>
      </div>

      <div class="reminder-primary-actions">
        <button type="button" class="btn-senior btn-take" id="confirmTakenBtn" ${
          state.isSubmitting ? 'disabled' : ''
        }>
          I Took My Medicine
        </button>
        <button type="button" class="btn-senior btn-snooze" id="snoozeDoseBtn" ${
          state.isSubmitting ? 'disabled' : ''
        }>
          Snooze 15 Mins
        </button>
      </div>

      <div class="reminder-secondary-actions">
        <button type="button" class="btn-senior btn-outline-senior" id="repeatVoicePromptBtn">
          ${isSpeechSupported() ? 'Read Instructions Aloud' : 'Voice Unavailable'}
        </button>
        <span style="font-size: 1rem; color: var(--text-secondary);">
          Remaining pills: <strong class="tabular-nums">${dose.remaining_quantity}</strong>
        </span>
      </div>
    `;
    els.overlay.classList.remove('hidden');

    document.getElementById('closeReminderXBtn')?.addEventListener('click', closeOverlay);
    document.getElementById('repeatVoicePromptBtn')?.addEventListener('click', () => {
      handleSpeakDose(dose);
    });
    document.getElementById('confirmTakenBtn')?.addEventListener('click', async () => {
      if (state.isSubmitting) return;
      state.isSubmitting = true;
      try {
        const result = await confirmDose({
          patient_id: state.activePatientId,
          medication_id: dose.medication_id,
          schedule_id: dose.schedule_id,
        });
        playConfirmationChime();
        stopSpeaking();
        state.activeReminderDose = null;
        state.confirmedDoseInfo = {
          dose,
          confirmationTime: result.log?.confirmation_time || new Date().toISOString(),
          remainingQuantity: result.remaining_quantity,
        };
        await loadDashboard(false);
        renderOverlay();
      } catch (err) {
        showToast(err instanceof Error ? err.message : 'Failed to confirm medication.');
      } finally {
        state.isSubmitting = false;
      }
    });

    document.getElementById('snoozeDoseBtn')?.addEventListener('click', async () => {
      if (state.isSubmitting) return;
      state.isSubmitting = true;
      try {
        const res = await snoozeDose({
          patient_id: state.activePatientId,
          schedule_id: dose.schedule_id,
          snooze_minutes: 15,
        });
        stopSpeaking();
        state.activeReminderDose = null;
        await loadDashboard(false);
        renderOverlay();
        showToast(`Reminder snoozed for 15 minutes (until ${res.snoozed_until_12h}).`);
      } catch (err) {
        showToast(err instanceof Error ? err.message : 'Unable to snooze reminder.');
      } finally {
        state.isSubmitting = false;
      }
    });
    return;
  }

  els.overlay.classList.add('hidden');
}

const scheduler = createReminderScheduler({
  onReminderDue: (dose) => {
    if (!state.activeReminderDose && !state.confirmedDoseInfo && !state.sosOpen) {
      openReminderScreen(dose, true);
    }
  },
});

async function loadDashboard(checkAutoDue = true) {
  try {
    const data = await fetchPatientDashboard(state.activePatientId);
    state.dashboard = data;
    renderDashboard();
    scheduler.updateSchedules(data.todayDoses || []);

    if (checkAutoDue && !state.activeReminderDose && !state.confirmedDoseInfo) {
      const dueNow = (data.todayDoses || []).find((d) => d.state === 'due');
      if (dueNow) {
        openReminderScreen(dueNow, false);
      }
    }
  } catch (err) {
    showToast(err instanceof Error ? err.message : 'Unable to load schedule.');
  }
}

async function init() {
  updateLiveClock();
  setInterval(updateLiveClock, 15000);
  updateNotificationBanner();

  try {
    const { patients } = await fetchPatients();
    state.patients = patients || [];
    if (!state.patients.some((p) => p.id === state.activePatientId) && state.patients[0]) {
      state.activePatientId = state.patients[0].id;
    }
    renderSelectors();
    await loadDashboard(true);
  } catch (err) {
    showToast(err instanceof Error ? err.message : 'Unable to connect to PillPing server.');
  }

  els.patientSelect?.addEventListener('change', async (e) => {
    state.activePatientId = Number(e.target.value);
    localStorage.setItem(STORAGE_PATIENT_KEY, String(state.activePatientId));
    closeOverlay();
    await loadDashboard(true);
  });

  els.languageSelect?.addEventListener('change', (e) => {
    state.language = e.target.value;
    localStorage.setItem(STORAGE_LANG_KEY, state.language);
  });

  els.periodFilters?.querySelectorAll('[data-period]').forEach((btn) => {
    btn.addEventListener('click', () => {
      state.periodFilter = btn.getAttribute('data-period') || 'All';
      els.periodFilters.querySelectorAll('[data-period]').forEach((b) => {
        b.classList.toggle('is-active', b === btn);
      });
      renderDoseGrid();
    });
  });

  els.enableNotifBtn?.addEventListener('click', async () => {
    await requestNotificationPermission();
    updateNotificationBanner();
    playReminderChime();
  });

  els.testChimeBtn?.addEventListener('click', () => {
    playReminderChime();
    showToast('Reminder chime tested.');
  });

  els.sosHeaderBtn?.addEventListener('click', () => {
    state.activeReminderDose = null;
    state.confirmedDoseInfo = null;
    state.sosOpen = true;
    renderOverlay();
  });

  els.demoTriggerBtn?.addEventListener('click', () => {
    const doses = state.dashboard?.todayDoses || [];
    const amlodipine =
      doses.find((d) => d.medicine_name.toLowerCase().includes('amlodipine') && d.state !== 'taken') ||
      doses.find((d) => d.state !== 'taken') ||
      doses[0];

    if (!amlodipine) {
      showToast('No medication scheduled to demonstrate.');
      return;
    }
    openReminderScreen(amlodipine, true);
  });

  subscribeToSyncEvents({
    onEvent: (eventType, payload) => {
      if (eventType === 'connected') return;
      if (!payload.patientId || Number(payload.patientId) === state.activePatientId || eventType === 'demo:reset') {
        loadDashboard(false);
      }
    },
  });
}

init();
