import { escapeHtml, formatIsoTo12Hour } from './api.js';

function formatShortDay(dateStr) {
  const [y, m, d] = dateStr.split('-').map(Number);
  const dt = new Date(y, m - 1, d);
  const weekday = dt.toLocaleDateString([], { weekday: 'short' });
  return { weekday, dayNum: d };
}

function formatReadableDate(dateStr) {
  const [y, m, d] = dateStr.split('-').map(Number);
  const dt = new Date(y, m - 1, d);
  return dt.toLocaleDateString([], { weekday: 'long', month: 'short', day: 'numeric' });
}

export function renderWeeklyScorecard({
  scorecardEl,
  calendarEl,
  dayDetailEl,
  weeklyStats,
  calendarDays,
  historicalLogs,
  todayDoses,
  todayStr,
  selectedDate,
  onSelectDate,
}) {
  if (scorecardEl) {
    scorecardEl.innerHTML = `
      <div class="kpi-card">
        <div class="kpi-label">Weekly Adherence</div>
        <div class="kpi-value tabular-nums">${weeklyStats.adherencePercentage}%</div>
        <div class="kpi-subtext">${weeklyStats.completed} of ${weeklyStats.completed + weeklyStats.missed} resolved doses</div>
      </div>
      <div class="kpi-card">
        <div class="kpi-label">Total Scheduled (7d)</div>
        <div class="kpi-value tabular-nums">${weeklyStats.totalScheduled}</div>
        <div class="kpi-subtext">Across active schedules</div>
      </div>
      <div class="kpi-card">
        <div class="kpi-label">Completed Doses</div>
        <div class="kpi-value tabular-nums" style="color: var(--status-green);">${weeklyStats.completed}</div>
        <div class="kpi-subtext">On-time &amp; retroactive</div>
      </div>
      <div class="kpi-card">
        <div class="kpi-label">Missed / Pending</div>
        <div class="kpi-value tabular-nums" style="color: ${
          weeklyStats.missed > 0 ? 'var(--status-red)' : 'var(--status-amber)'
        };">${weeklyStats.missed} / ${weeklyStats.pending}</div>
        <div class="kpi-subtext">${weeklyStats.missed} missed · ${weeklyStats.pending} pending</div>
      </div>
    `;
  }

  if (calendarEl) {
    calendarEl.innerHTML = calendarDays
      .map((day) => {
        const { weekday, dayNum } = formatShortDay(day.date);
        const colorClass =
          day.colorStatus === 'green'
            ? 'cal-green'
            : day.colorStatus === 'red'
            ? 'cal-red'
            : day.colorStatus === 'yellow'
            ? 'cal-yellow'
            : '';
        const selectedClass = day.date === selectedDate ? 'is-selected' : '';
        const statusSummary =
          day.total === 0
            ? 'No logs'
            : day.missed > 0
            ? `${day.missed} missed`
            : day.pending > 0
            ? `${day.pending} pending`
            : `${day.completed}/${day.total} OK`;

        return `
          <button
            type="button"
            class="calendar-day-btn ${colorClass} ${selectedClass}"
            data-cal-date="${escapeHtml(day.date)}"
            aria-label="${escapeHtml(formatReadableDate(day.date))}: ${escapeHtml(statusSummary)}"
          >
            <span class="calendar-day-name">${escapeHtml(weekday)}</span>
            <span class="calendar-day-num">${dayNum}</span>
            <span class="calendar-day-stat tabular-nums">${escapeHtml(statusSummary)}</span>
          </button>
        `;
      })
      .join('');

    calendarEl.querySelectorAll('[data-cal-date]').forEach((btn) => {
      btn.addEventListener('click', () => {
        onSelectDate?.(btn.getAttribute('data-cal-date'));
      });
    });
  }

  if (dayDetailEl && selectedDate) {
    const logsForDay = historicalLogs.filter((l) => l.log_date === selectedDate);
    let rowsHtml = '';

    if (selectedDate === todayStr) {
      rowsHtml = todayDoses
        .map((d) => {
          const statusLabel =
            d.state === 'taken'
              ? d.log?.confirmation_type === 'retroactive'
                ? 'Taken (Retroactive)'
                : 'Taken'
              : d.state === 'overdue'
              ? `Overdue (${d.minutes_overdue}m)`
              : d.state === 'missed'
              ? 'Missed'
              : d.state === 'snoozed'
              ? `Snoozed until ${d.snoozed_until_12h}`
              : d.state === 'due'
              ? 'Due Now'
              : 'Upcoming';

          const statusClass =
            d.state === 'taken'
              ? 'is-green'
              : d.state === 'overdue' || d.state === 'missed'
              ? 'is-red'
              : 'is-amber';

          const confirmDetail = d.log?.confirmation_time
            ? `Logged at ${formatIsoTo12Hour(d.log.confirmation_time)}${
                d.log.reported_taken_time ? ` (Reported: ${escapeHtml(d.log.reported_taken_time)})` : ''
              }`
            : 'Not yet confirmed';

          return `
            <tr>
              <td class="font-mono-num">${escapeHtml(d.scheduled_time_12h)}</td>
              <td><strong>${escapeHtml(d.medicine_name)}</strong> ${escapeHtml(d.dosage)}</td>
              <td><span class="status-label ${statusClass}">${escapeHtml(statusLabel)}</span></td>
              <td>${confirmDetail}</td>
            </tr>
          `;
        })
        .join('');
    } else if (logsForDay.length > 0) {
      rowsHtml = logsForDay
        .map((l) => {
          const statusClass =
            l.status === 'taken' || l.status === 'retroactive'
              ? 'is-green'
              : l.status === 'missed'
              ? 'is-red'
              : 'is-amber';
          const statusText =
            l.status === 'retroactive'
              ? 'Taken (Retroactive)'
              : l.status === 'taken'
              ? 'Taken On Time'
              : l.status === 'missed'
              ? 'Missed'
              : 'Pending';

          const confirmDetail = l.confirmation_time
            ? `Recorded ${formatIsoTo12Hour(l.confirmation_time)}${
                l.reported_taken_time ? ` · Reported: ${escapeHtml(l.reported_taken_time)}` : ''
              }`
            : escapeHtml(l.note || 'Unconfirmed');

          return `
            <tr>
              <td class="font-mono-num">${escapeHtml(l.scheduled_time)}</td>
              <td><strong>${escapeHtml(l.medicine_name)}</strong> ${escapeHtml(l.dosage)}</td>
              <td><span class="status-label ${statusClass}">${escapeHtml(statusText)}</span></td>
              <td>${confirmDetail}</td>
            </tr>
          `;
        })
        .join('');
    }

    dayDetailEl.innerHTML = `
      <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px;">
        <strong>Audit Log: ${escapeHtml(formatReadableDate(selectedDate))}</strong>
      </div>
      ${
        rowsHtml
          ? `<div class="cg-table-wrap"><table class="cg-table">
              <thead><tr><th>Scheduled</th><th>Medication</th><th>Status</th><th>Confirmation Detail</th></tr></thead>
              <tbody>${rowsHtml}</tbody>
            </table></div>`
          : `<p class="cg-panel-subtitle">No medication records logged for this date.</p>`
      }
    `;
  }
}
