import {
  createMedication,
  deleteMedication,
  escapeHtml,
  refillMedication,
  updateMedication,
} from './api.js';

const ALLOWED_IMAGE_TYPES = ['image/png', 'image/jpeg', 'image/webp'];
const MAX_IMAGE_SIZE = 1_500_000;

export function createMedicationModalController({ onSaved, onError }) {
  const backdrop = document.getElementById('medModalBackdrop');
  const form = document.getElementById('medForm');
  const titleEl = document.getElementById('medModalTitle');
  const errorEl = document.getElementById('medFormError');
  const schedulesContainer = document.getElementById('medSchedulesList');
  const addScheduleBtn = document.getElementById('addScheduleRowBtn');
  const cancelBtn = document.getElementById('cancelMedModalBtn');
  const photoInput = document.getElementById('medBottlePhotoInput');
  const photoPreview = document.getElementById('medBottlePreview');
  const clearPhotoBtn = document.getElementById('clearBottlePhotoBtn');

  let activePatientId = null;
  let editingMedId = null;
  let currentPhotoDataUrl = '';
  let scheduleRows = [];

  function inferPeriodFromTime(hhmm) {
    const h = Number(String(hhmm || '08:00').split(':')[0]);
    if (h < 12) return 'Morning';
    if (h < 17) return 'Afternoon';
    return 'Night';
  }

  function renderScheduleRows() {
    if (!schedulesContainer) return;
    schedulesContainer.innerHTML = scheduleRows
      .map(
        (row, idx) => `
        <div class="schedule-builder-row">
          <input
            type="time"
            class="cg-input"
            value="${escapeHtml(row.scheduled_time)}"
            data-sched-time="${idx}"
            aria-label="Scheduled time ${idx + 1}"
            required
          />
          <select
            class="cg-select"
            data-sched-period="${idx}"
            aria-label="Schedule period ${idx + 1}"
          >
            <option value="Morning" ${row.schedule_period === 'Morning' ? 'selected' : ''}>Morning</option>
            <option value="Afternoon" ${row.schedule_period === 'Afternoon' ? 'selected' : ''}>Afternoon</option>
            <option value="Night" ${row.schedule_period === 'Night' ? 'selected' : ''}>Night</option>
          </select>
          <button
            type="button"
            class="btn-cg btn-cg-danger"
            data-remove-sched="${idx}"
            ${scheduleRows.length <= 1 ? 'disabled' : ''}
            aria-label="Remove schedule time ${idx + 1}"
          >
            Remove
          </button>
        </div>
      `
      )
      .join('');

    schedulesContainer.querySelectorAll('[data-sched-time]').forEach((input) => {
      input.addEventListener('change', (e) => {
        const idx = Number(input.getAttribute('data-sched-time'));
        const val = e.target.value;
        scheduleRows[idx].scheduled_time = val;
        scheduleRows[idx].schedule_period = inferPeriodFromTime(val);
        renderScheduleRows();
      });
    });

    schedulesContainer.querySelectorAll('[data-sched-period]').forEach((sel) => {
      sel.addEventListener('change', (e) => {
        const idx = Number(sel.getAttribute('data-sched-period'));
        scheduleRows[idx].schedule_period = e.target.value;
      });
    });

    schedulesContainer.querySelectorAll('[data-remove-sched]').forEach((btn) => {
      btn.addEventListener('click', () => {
        if (scheduleRows.length <= 1) return;
        const idx = Number(btn.getAttribute('data-remove-sched'));
        scheduleRows.splice(idx, 1);
        renderScheduleRows();
      });
    });
  }

  function updatePhotoPreview(src) {
    currentPhotoDataUrl = src || '';
    if (photoPreview) {
      if (currentPhotoDataUrl) {
        photoPreview.src = currentPhotoDataUrl;
        photoPreview.classList.remove('hidden');
      } else {
        photoPreview.src = '';
        photoPreview.classList.add('hidden');
      }
    }
    if (clearPhotoBtn) {
      clearPhotoBtn.classList.toggle('hidden', !currentPhotoDataUrl);
    }
  }

  function open({ patientId, medication = null }) {
    activePatientId = patientId;
    editingMedId = medication ? medication.id : null;
    if (errorEl) errorEl.textContent = '';

    if (titleEl) {
      titleEl.textContent = medication ? `Edit ${medication.medicine_name}` : 'Add New Medication';
    }

    if (form) {
      form.elements.medicine_name.value = medication?.medicine_name || '';
      form.elements.purpose_label.value = medication?.purpose_label || '';
      form.elements.dosage.value = medication?.dosage || '';
      form.elements.frequency.value = medication?.frequency || 'Once Daily';
      form.elements.instructions.value = medication?.instructions || 'Take with Water';
      form.elements.with_food.value = medication?.with_food || 'any';
      form.elements.pill_color.value = medication?.pill_color || 'blue';
      form.elements.remaining_quantity.value =
        medication?.remaining_quantity !== undefined ? String(medication.remaining_quantity) : '30';
    }

    scheduleRows =
      medication?.schedules?.length > 0
        ? medication.schedules.map((s) => ({
            scheduled_time: s.scheduled_time,
            schedule_period: s.schedule_period,
          }))
        : [{ scheduled_time: '09:00', schedule_period: 'Morning' }];

    renderScheduleRows();
    updatePhotoPreview(medication?.bottle_image || '');
    if (photoInput) photoInput.value = '';
    backdrop?.classList.remove('hidden');
  }

  function close() {
    backdrop?.classList.add('hidden');
  }

  addScheduleBtn?.addEventListener('click', () => {
    scheduleRows.push({ scheduled_time: '20:00', schedule_period: 'Night' });
    renderScheduleRows();
  });

  cancelBtn?.addEventListener('click', close);

  clearPhotoBtn?.addEventListener('click', () => {
    updatePhotoPreview('');
    if (photoInput) photoInput.value = '';
  });

  photoInput?.addEventListener('change', (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!ALLOWED_IMAGE_TYPES.includes(file.type)) {
      if (errorEl) errorEl.textContent = 'Please select a PNG, JPEG, or WebP bottle image.';
      photoInput.value = '';
      return;
    }
    if (file.size > MAX_IMAGE_SIZE) {
      if (errorEl) errorEl.textContent = 'Image must be smaller than 1.5 MB.';
      photoInput.value = '';
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      if (errorEl) errorEl.textContent = '';
      updatePhotoPreview(String(reader.result || ''));
    };
    reader.readAsDataURL(file);
  });

  form?.addEventListener('submit', async (e) => {
    e.preventDefault();
    if (errorEl) errorEl.textContent = '';

    const payload = {
      patient_id: activePatientId,
      medicine_name: form.elements.medicine_name.value.trim(),
      purpose_label: form.elements.purpose_label.value.trim(),
      dosage: form.elements.dosage.value.trim(),
      frequency: form.elements.frequency.value.trim(),
      instructions: form.elements.instructions.value.trim(),
      with_food: form.elements.with_food.value,
      pill_color: form.elements.pill_color.value,
      remaining_quantity: Number(form.elements.remaining_quantity.value),
      bottle_image: currentPhotoDataUrl,
      schedules: scheduleRows,
    };

    try {
      if (editingMedId) {
        await updateMedication(editingMedId, payload);
      } else {
        await createMedication(payload);
      }
      close();
      onSaved?.();
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Unable to save medication.';
      if (errorEl) errorEl.textContent = msg;
      onError?.(msg);
    }
  });

  return { open, close };
}

export function renderMedicationTable({
  containerEl,
  medications,
  onEdit,
  onDelete,
  onRefill,
}) {
  if (!containerEl) return;

  if (!medications || medications.length === 0) {
    containerEl.innerHTML = `
      <p class="cg-panel-subtitle">No medications configured yet. Click "Add Medication" to create a schedule.</p>
    `;
    return;
  }

  const rowsHtml = medications
    .map((med) => {
      const scheduleText = (med.schedules || [])
        .map((s) => `${s.schedule_period} (${s.scheduled_time_12h})`)
        .join(', ');
      const isLow = med.refillStatus?.isLow;
      const thumbHtml = med.bottle_image
        ? `<img class="med-thumb" src="${escapeHtml(med.bottle_image)}" alt="${escapeHtml(
            med.medicine_name
          )} bottle" referrerPolicy="no-referrer" />`
        : `<div class="pill-swatch pill-color-${escapeHtml(med.pill_color)}" style="width:48px;height:48px;">
            <span style="font-size:0.75rem;font-weight:800;">RX</span>
           </div>`;

      return `
        <tr>
          <td>
            <div style="display:flex; align-items:center; gap:12px;">
              ${thumbHtml}
              <div>
                <strong>${escapeHtml(med.medicine_name)}</strong> (${escapeHtml(med.dosage)})
                <div class="cg-panel-subtitle">${escapeHtml(med.purpose_label || med.frequency)}</div>
              </div>
            </div>
          </td>
          <td>${escapeHtml(scheduleText || 'No schedule')}</td>
          <td>${escapeHtml(med.instructions)}</td>
          <td class="tabular-nums">
            <strong style="color:${isLow ? 'var(--status-red)' : 'var(--text-primary)'};">
              ${med.remaining_quantity} left
            </strong>
            ${isLow ? '<div class="status-label is-red">Refill Needed</div>' : ''}
          </td>
          <td>
            <div style="display:flex; gap:8px; flex-wrap:wrap;">
              <button type="button" class="btn-cg btn-cg-secondary" data-refill-med="${med.id}">+30 Refill</button>
              <button type="button" class="btn-cg btn-cg-secondary" data-edit-med="${med.id}">Edit</button>
              <button type="button" class="btn-cg btn-cg-danger" data-delete-med="${med.id}">Delete</button>
            </div>
          </td>
        </tr>
      `;
    })
    .join('');

  containerEl.innerHTML = `
    <div class="cg-table-wrap">
      <table class="cg-table">
        <thead>
          <tr>
            <th>Medication</th>
            <th>Schedule</th>
            <th>Instructions</th>
            <th>Inventory</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>${rowsHtml}</tbody>
      </table>
    </div>
  `;

  containerEl.querySelectorAll('[data-edit-med]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const id = Number(btn.getAttribute('data-edit-med'));
      const med = medications.find((m) => m.id === id);
      if (med) onEdit?.(med);
    });
  });

  containerEl.querySelectorAll('[data-refill-med]').forEach((btn) => {
    btn.addEventListener('click', async () => {
      const id = Number(btn.getAttribute('data-refill-med'));
      await refillMedication(id, 30);
      onRefill?.();
    });
  });

  containerEl.querySelectorAll('[data-delete-med]').forEach((btn) => {
    btn.addEventListener('click', async () => {
      const id = Number(btn.getAttribute('data-delete-med'));
      await deleteMedication(id);
      onDelete?.();
    });
  });
}
