import fs from 'node:fs';
import path from 'node:path';
import { DatabaseSync } from 'node:sqlite';
import {
  checkRefillWarning,
  classifyDoseState,
  computeAdherenceStats,
  computeDailyBreakdown,
  decrementInventory,
  formatTime12Hour,
  getMinutesOverdue,
  parseTimeToMinutes,
  type AdherenceRecord,
} from '../logic/scheduling.ts';

export interface SampleDataset {
  datasetLabel: string;
  patients: Array<{
    id: number;
    name: string;
    age: number;
    contact_number: string;
    preferred_greeting: string;
    conditions: string;
    avatar_url: string;
    is_sample: number;
    caregiver: {
      name: string;
      email: string;
      contact_number: string;
      relationship: string;
    };
    medications: Array<{
      medicine_name: string;
      purpose_label: string;
      dosage: string;
      frequency: string;
      instructions: string;
      with_food: string;
      pill_color: string;
      remaining_quantity: number;
      bottle_image: string;
      schedules: Array<{
        scheduled_time: string;
        schedule_period: 'Morning' | 'Afternoon' | 'Night';
      }>;
    }>;
  }>;
}

const DATA_DIR = path.resolve(process.cwd(), 'data');
const DB_PATH = path.join(DATA_DIR, 'pillping.db');
const SAMPLE_JSON_PATH = path.resolve(process.cwd(), 'src/data/sampleDataset.json');

let dbInstance: DatabaseSync | null = null;

export function getLocalDateStr(date: Date = new Date()): string {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

export function getLocalTimeHHMM(date: Date = new Date()): string {
  const h = String(date.getHours()).padStart(2, '0');
  const m = String(date.getMinutes()).padStart(2, '0');
  return `${h}:${m}`;
}

export function shiftDateStr(baseDateStr: string, offsetDays: number): string {
  const [y, m, d] = baseDateStr.split('-').map(Number);
  const dt = new Date(y, m - 1, d + offsetDays);
  return getLocalDateStr(dt);
}

export function getDb(): DatabaseSync {
  if (dbInstance) {
    return dbInstance;
  }
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
  const db = new DatabaseSync(DB_PATH);
  db.exec('PRAGMA foreign_keys = ON;');
  db.exec('PRAGMA journal_mode = WAL;');
  initSchema(db);
  seedSampleDatasetIfEmpty(db);
  dbInstance = db;
  return db;
}

function initSchema(db: DatabaseSync): void {
  db.exec(`
    CREATE TABLE IF NOT EXISTS patients (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      age INTEGER NOT NULL,
      contact_number TEXT NOT NULL DEFAULT '',
      preferred_greeting TEXT NOT NULL DEFAULT 'Friend',
      conditions TEXT NOT NULL DEFAULT '',
      avatar_url TEXT NOT NULL DEFAULT '',
      is_sample INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS caregivers (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      patient_id INTEGER NOT NULL,
      name TEXT NOT NULL,
      email TEXT NOT NULL DEFAULT '',
      contact_number TEXT NOT NULL,
      relationship TEXT NOT NULL DEFAULT 'Family Caregiver',
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS medications (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      patient_id INTEGER NOT NULL,
      medicine_name TEXT NOT NULL,
      purpose_label TEXT NOT NULL DEFAULT '',
      dosage TEXT NOT NULL,
      frequency TEXT NOT NULL DEFAULT 'Once Daily',
      instructions TEXT NOT NULL DEFAULT '',
      with_food TEXT NOT NULL DEFAULT 'any',
      pill_color TEXT NOT NULL DEFAULT 'blue',
      remaining_quantity INTEGER NOT NULL DEFAULT 30,
      bottle_image TEXT NOT NULL DEFAULT '',
      is_sample INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS dose_schedules (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      medication_id INTEGER NOT NULL,
      scheduled_time TEXT NOT NULL,
      schedule_period TEXT NOT NULL CHECK (schedule_period IN ('Morning', 'Afternoon', 'Night')),
      active INTEGER NOT NULL DEFAULT 1,
      snoozed_until_date TEXT DEFAULT NULL,
      snoozed_until_time TEXT DEFAULT NULL,
      FOREIGN KEY (medication_id) REFERENCES medications(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS adherence_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      patient_id INTEGER NOT NULL,
      medication_id INTEGER NOT NULL,
      schedule_id INTEGER,
      log_date TEXT NOT NULL,
      scheduled_time TEXT NOT NULL,
      confirmation_time TEXT,
      reported_taken_time TEXT,
      status TEXT NOT NULL CHECK (status IN ('taken', 'retroactive', 'missed', 'pending', 'snoozed')),
      confirmation_type TEXT NOT NULL DEFAULT 'senior_tap',
      note TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE,
      FOREIGN KEY (medication_id) REFERENCES medications(id) ON DELETE CASCADE,
      FOREIGN KEY (schedule_id) REFERENCES dose_schedules(id) ON DELETE SET NULL
    );

    CREATE UNIQUE INDEX IF NOT EXISTS idx_adherence_unique_schedule_day
      ON adherence_logs (schedule_id, log_date)
      WHERE schedule_id IS NOT NULL;

    CREATE TABLE IF NOT EXISTS caregiver_alerts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      patient_id INTEGER NOT NULL,
      medication_id INTEGER NOT NULL,
      schedule_id INTEGER,
      alert_date TEXT NOT NULL,
      scheduled_time TEXT NOT NULL DEFAULT '',
      alert_type TEXT NOT NULL CHECK (alert_type IN ('missed_dose', 'refill_low')),
      message TEXT NOT NULL,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      resolved_at TEXT,
      status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'resolved')),
      FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE,
      FOREIGN KEY (medication_id) REFERENCES medications(id) ON DELETE CASCADE,
      FOREIGN KEY (schedule_id) REFERENCES dose_schedules(id) ON DELETE SET NULL
    );
  `);
}

function seedSampleDatasetIfEmpty(db: DatabaseSync): void {
  const row = db.prepare('SELECT COUNT(*) AS count FROM patients').get() as { count: number };
  if (row && row.count > 0) {
    return;
  }
  resetAndSeedSampleDataset(db);
}

export function resetAndSeedSampleDataset(db: DatabaseSync, referenceDate?: string): void {
  const raw = fs.readFileSync(SAMPLE_JSON_PATH, 'utf-8');
  const dataset = JSON.parse(raw) as SampleDataset;
  const todayStr = referenceDate ?? getLocalDateStr();
  const nowMinutes = parseTimeToMinutes(getLocalTimeHHMM());

  db.exec('DELETE FROM caregiver_alerts;');
  db.exec('DELETE FROM adherence_logs;');
  db.exec('DELETE FROM dose_schedules;');
  db.exec('DELETE FROM medications;');
  db.exec('DELETE FROM caregivers;');
  db.exec('DELETE FROM patients;');
  db.exec("DELETE FROM sqlite_sequence WHERE name IN ('patients','caregivers','medications','dose_schedules','adherence_logs','caregiver_alerts');");

  const insertPatient = db.prepare(`
    INSERT INTO patients (name, age, contact_number, preferred_greeting, conditions, avatar_url, is_sample)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `);
  const insertCaregiver = db.prepare(`
    INSERT INTO caregivers (patient_id, name, email, contact_number, relationship)
    VALUES (?, ?, ?, ?, ?)
  `);
  const insertMed = db.prepare(`
    INSERT INTO medications (
      patient_id, medicine_name, purpose_label, dosage, frequency,
      instructions, with_food, pill_color, remaining_quantity, bottle_image, is_sample
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)
  `);
  const insertSched = db.prepare(`
    INSERT INTO dose_schedules (medication_id, scheduled_time, schedule_period, active)
    VALUES (?, ?, ?, 1)
  `);
  const insertLog = db.prepare(`
    INSERT INTO adherence_logs (
      patient_id, medication_id, schedule_id, log_date, scheduled_time,
      confirmation_time, reported_taken_time, status, confirmation_type, note
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  const insertAlert = db.prepare(`
    INSERT INTO caregiver_alerts (
      patient_id, medication_id, schedule_id, alert_date, scheduled_time,
      alert_type, message, status
    ) VALUES (?, ?, ?, ?, ?, ?, ?, 'active')
  `);

  for (const patientData of dataset.patients) {
    const pRes = insertPatient.run(
      patientData.name,
      patientData.age,
      patientData.contact_number,
      patientData.preferred_greeting,
      patientData.conditions,
      patientData.avatar_url,
      patientData.is_sample
    );
    const patientId = Number(pRes.lastInsertRowid);

    insertCaregiver.run(
      patientId,
      patientData.caregiver.name,
      patientData.caregiver.email,
      patientData.caregiver.contact_number,
      patientData.caregiver.relationship
    );

    const createdSchedules: Array<{
      scheduleId: number;
      medicationId: number;
      medicineName: string;
      dosage: string;
      scheduledTime: string;
    }> = [];

    for (const medData of patientData.medications) {
      const mRes = insertMed.run(
        patientId,
        medData.medicine_name,
        medData.purpose_label,
        medData.dosage,
        medData.frequency,
        medData.instructions,
        medData.with_food,
        medData.pill_color,
        medData.remaining_quantity,
        medData.bottle_image
      );
      const medId = Number(mRes.lastInsertRowid);

      // Refill warning if < 5
      const refillStatus = checkRefillWarning(medData.remaining_quantity);
      if (refillStatus.isLow) {
        insertAlert.run(
          patientId,
          medId,
          null,
          todayStr,
          '',
          'refill_low',
          `${medData.medicine_name} ${medData.dosage} is running low (${medData.remaining_quantity} pills remaining).`
        );
      }

      for (const sched of medData.schedules) {
        const sRes = insertSched.run(medId, sched.scheduled_time, sched.schedule_period);
        createdSchedules.push({
          scheduleId: Number(sRes.lastInsertRowid),
          medicationId: medId,
          medicineName: medData.medicine_name,
          dosage: medData.dosage,
          scheduledTime: sched.scheduled_time,
        });
      }
    }

    // Seed 14-day historical adherence logs (days -14 through -1)
    for (let dayOffset = -14; dayOffset <= -1; dayOffset++) {
      const logDate = shiftDateStr(todayStr, dayOffset);
      for (let idx = 0; idx < createdSchedules.length; idx++) {
        const item = createdSchedules[idx];
        const schedMinutes = parseTimeToMinutes(item.scheduledTime);
        // Deterministic realistic adherence (~93% for patient 1, ~86% for patient 2)
        const missedPattern =
          (patientId === 1 && dayOffset === -4 && idx === 3) ||
          (patientId === 1 && dayOffset === -10 && idx === 2) ||
          (patientId === 2 && dayOffset === -2 && idx === 1) ||
          (patientId === 2 && dayOffset === -6 && idx === 3) ||
          (patientId === 2 && dayOffset === -11 && idx === 0);

        const retroactivePattern =
          (patientId === 1 && dayOffset === -2 && idx === 1) ||
          (patientId === 2 && dayOffset === -5 && idx === 2);

        if (missedPattern) {
          insertLog.run(
            patientId,
            item.medicationId,
            item.scheduleId,
            logDate,
            item.scheduledTime,
            null,
            null,
            'missed',
            'system_missed',
            'Unconfirmed past grace window'
          );
        } else if (retroactivePattern) {
          const reportedTime = formatTime12Hour(schedMinutes + 6);
          insertLog.run(
            patientId,
            item.medicationId,
            item.scheduleId,
            logDate,
            item.scheduledTime,
            `${logDate}T18:30:00`,
            `${logDate} ${reportedTime}`,
            'retroactive',
            'retroactive',
            'Caregiver verified patient took dose on time'
          );
        } else {
          const confirmMins = schedMinutes + ((idx + Math.abs(dayOffset)) % 7) + 1;
          const confH = String(Math.floor(confirmMins / 60) % 24).padStart(2, '0');
          const confM = String(confirmMins % 60).padStart(2, '0');
          insertLog.run(
            patientId,
            item.medicationId,
            item.scheduleId,
            logDate,
            item.scheduledTime,
            `${logDate}T${confH}:${confM}:00`,
            null,
            'taken',
            'senior_tap',
            ''
          );
        }
      }
    }

    // Seed today's initial logs for demonstration clarity:
    // For Robert (patient 1): 08:00 AM Metformin is already confirmed at 08:03 AM today.
    // 10:00 AM Amlodipine remains unconfirmed/pending so the demo scenario can always be run!
    if (patientId === 1) {
      const morningMetformin = createdSchedules.find(
        (s) => s.medicineName === 'Metformin' && s.scheduledTime === '08:00'
      );
      if (morningMetformin) {
        insertLog.run(
          patientId,
          morningMetformin.medicationId,
          morningMetformin.scheduleId,
          todayStr,
          '08:00',
          `${todayStr}T08:03:00`,
          null,
          'taken',
          'senior_tap',
          ''
        );
      }
    }

    // For Eleanor (patient 2): if 07:30 AM is > 30 mins in the past, generate an active missed_dose alert;
    // otherwise leave pending or simulate an overdue dose alert for demonstration.
    if (patientId === 2) {
      const morningMetformin = createdSchedules.find(
        (s) => s.medicineName === 'Metformin' && s.scheduledTime === '07:30'
      );
      if (morningMetformin && nowMinutes > parseTimeToMinutes('07:30') + 30) {
        const minsOverdue = nowMinutes - parseTimeToMinutes('07:30');
        insertAlert.run(
          patientId,
          morningMetformin.medicationId,
          morningMetformin.scheduleId,
          todayStr,
          '07:30',
          'missed_dose',
          `${morningMetformin.medicineName} ${morningMetformin.dosage} (7:30 AM) unconfirmed for ${minsOverdue} mins.`
        );
      }
    }
  }
}

export function runMissedDoseEscalations(
  db: DatabaseSync,
  todayStr: string = getLocalDateStr(),
  nowMinutes: number = parseTimeToMinutes(getLocalTimeHHMM())
): number {
  // Find all active schedules that do not have a 'taken', 'retroactive', or 'missed' log for today
  const schedules = db
    .prepare(`
      SELECT
        ds.id AS schedule_id,
        ds.medication_id,
        ds.scheduled_time,
        ds.snoozed_until_date,
        ds.snoozed_until_time,
        m.patient_id,
        m.medicine_name,
        m.dosage,
        al.status AS log_status
      FROM dose_schedules ds
      JOIN medications m ON m.id = ds.medication_id
      LEFT JOIN adherence_logs al
        ON al.schedule_id = ds.id AND al.log_date = ?
      WHERE ds.active = 1
    `)
    .all(todayStr) as Array<{
    schedule_id: number;
    medication_id: number;
    scheduled_time: string;
    snoozed_until_date: string | null;
    snoozed_until_time: string | null;
    patient_id: number;
    medicine_name: string;
    dosage: string;
    log_status: string | null;
  }>;

  let createdOrUpdated = 0;

  const existingAlertStmt = db.prepare(`
    SELECT id FROM caregiver_alerts
    WHERE schedule_id = ? AND alert_date = ? AND alert_type = 'missed_dose' AND status = 'active'
  `);
  const insertAlertStmt = db.prepare(`
    INSERT INTO caregiver_alerts (
      patient_id, medication_id, schedule_id, alert_date, scheduled_time, alert_type, message, status
    ) VALUES (?, ?, ?, ?, ?, 'missed_dose', ?, 'active')
  `);
  const updateAlertStmt = db.prepare(`
    UPDATE caregiver_alerts SET message = ? WHERE id = ?
  `);

  for (const s of schedules) {
    if (s.log_status === 'taken' || s.log_status === 'retroactive' || s.log_status === 'missed') {
      continue;
    }

    // Keep Robert's 10:00 AM Amlodipine in 'due' state for demo if user hasn't explicitly simulated overdue,
    // wait: let's ONLY exclude Amlodipine? No! The prompt says:
    // "If a scheduled medication dose remains unconfirmed for 30 minutes after its scheduled time: Mark the dose as overdue. Generate an urgent caregiver alert."
    // So we must genuinely evaluate every schedule by the real clock!
    const snoozedMinutes =
      s.snoozed_until_date === todayStr && s.snoozed_until_time
        ? parseTimeToMinutes(s.snoozed_until_time)
        : null;

    const state = classifyDoseState({
      scheduledTimeHHMM: s.scheduled_time,
      currentTimeMinutes: nowMinutes,
      isTaken: false,
      snoozedUntilMinutes: snoozedMinutes,
    });

    if (state === 'overdue') {
      const overdueMins = getMinutesOverdue({
        scheduledTimeHHMM: s.scheduled_time,
        currentTimeMinutes: nowMinutes,
        snoozedUntilMinutes: snoozedMinutes,
      });
      const msg = `${s.medicine_name} ${s.dosage} (${formatTime12Hour(
        s.scheduled_time
      )}) unconfirmed for ${overdueMins} mins.`;

      const existing = existingAlertStmt.get(s.schedule_id, todayStr) as { id: number } | undefined;
      if (existing) {
        updateAlertStmt.run(msg, existing.id);
      } else {
        insertAlertStmt.run(
          s.patient_id,
          s.medication_id,
          s.schedule_id,
          todayStr,
          s.scheduled_time,
          msg
        );
        createdOrUpdated += 1;
      }
    }
  }

  return createdOrUpdated;
}

export function getPatientDashboardData(
  db: DatabaseSync,
  patientId: number,
  todayStr: string = getLocalDateStr(),
  nowMinutes: number = parseTimeToMinutes(getLocalTimeHHMM())
) {
  const patient = db
    .prepare('SELECT * FROM patients WHERE id = ?')
    .get(patientId) as Record<string, unknown> | undefined;

  if (!patient) {
    return null;
  }

  const caregiver = db
    .prepare('SELECT * FROM caregivers WHERE patient_id = ? ORDER BY id ASC LIMIT 1')
    .get(patientId) as Record<string, unknown> | undefined;

  const medications = db
    .prepare('SELECT * FROM medications WHERE patient_id = ? ORDER BY id ASC')
    .all(patientId) as Array<{
    id: number;
    patient_id: number;
    medicine_name: string;
    purpose_label: string;
    dosage: string;
    frequency: string;
    instructions: string;
    with_food: string;
    pill_color: string;
    remaining_quantity: number;
    bottle_image: string;
    is_sample: number;
  }>;

  const schedules = db
    .prepare(`
      SELECT ds.*, m.medicine_name, m.purpose_label, m.dosage, m.instructions, m.with_food, m.pill_color, m.remaining_quantity, m.bottle_image
      FROM dose_schedules ds
      JOIN medications m ON m.id = ds.medication_id
      WHERE m.patient_id = ? AND ds.active = 1
      ORDER BY ds.scheduled_time ASC
    `)
    .all(patientId) as Array<{
    id: number;
    medication_id: number;
    scheduled_time: string;
    schedule_period: 'Morning' | 'Afternoon' | 'Night';
    active: number;
    snoozed_until_date: string | null;
    snoozed_until_time: string | null;
    medicine_name: string;
    purpose_label: string;
    dosage: string;
    instructions: string;
    with_food: string;
    pill_color: string;
    remaining_quantity: number;
    bottle_image: string;
  }>;

  const todayLogs = db
    .prepare('SELECT * FROM adherence_logs WHERE patient_id = ? AND log_date = ?')
    .all(patientId, todayStr) as Array<{
    id: number;
    schedule_id: number | null;
    medication_id: number;
    log_date: string;
    scheduled_time: string;
    confirmation_time: string | null;
    reported_taken_time: string | null;
    status: 'taken' | 'retroactive' | 'missed' | 'pending' | 'snoozed';
    confirmation_type: string;
    note: string;
  }>;

  const logBySchedule = new Map<number, (typeof todayLogs)[number]>();
  for (const log of todayLogs) {
    if (log.schedule_id !== null) {
      logBySchedule.set(log.schedule_id, log);
    }
  }

  const todayDoses = schedules.map((sched) => {
    const log = logBySchedule.get(sched.id);
    const isTaken = log?.status === 'taken' || log?.status === 'retroactive';
    const isMarkedMissed = log?.status === 'missed';
    const snoozedMinutes =
      sched.snoozed_until_date === todayStr && sched.snoozed_until_time
        ? parseTimeToMinutes(sched.snoozed_until_time)
        : null;

    let computedState: string;
    if (isMarkedMissed) {
      computedState = 'missed';
    } else {
      computedState = classifyDoseState({
        scheduledTimeHHMM: sched.scheduled_time,
        currentTimeMinutes: nowMinutes,
        isTaken,
        snoozedUntilMinutes: snoozedMinutes,
      });
    }

    const minutesOverdue =
      computedState === 'overdue'
        ? getMinutesOverdue({
            scheduledTimeHHMM: sched.scheduled_time,
            currentTimeMinutes: nowMinutes,
            snoozedUntilMinutes: snoozedMinutes,
          })
        : 0;

    return {
      schedule_id: sched.id,
      medication_id: sched.medication_id,
      medicine_name: sched.medicine_name,
      purpose_label: sched.purpose_label,
      dosage: sched.dosage,
      instructions: sched.instructions,
      with_food: sched.with_food,
      pill_color: sched.pill_color,
      remaining_quantity: sched.remaining_quantity,
      bottle_image: sched.bottle_image,
      scheduled_time: sched.scheduled_time,
      scheduled_time_12h: formatTime12Hour(sched.scheduled_time),
      schedule_period: sched.schedule_period,
      snoozed_until_time:
        sched.snoozed_until_date === todayStr ? sched.snoozed_until_time : null,
      snoozed_until_12h:
        sched.snoozed_until_date === todayStr && sched.snoozed_until_time
          ? formatTime12Hour(sched.snoozed_until_time)
          : null,
      state: computedState,
      minutes_overdue: minutesOverdue,
      log: log ?? null,
    };
  });

  // Build 14-day adherence records (last 14 days including today)
  const last14Dates: string[] = [];
  for (let i = -13; i <= 0; i++) {
    last14Dates.push(shiftDateStr(todayStr, i));
  }
  const last7Dates = last14Dates.slice(-7);
  const startDate14 = last14Dates[0];

  const historicalLogs = db
    .prepare(`
      SELECT al.*, m.medicine_name, m.dosage
      FROM adherence_logs al
      JOIN medications m ON m.id = al.medication_id
      WHERE al.patient_id = ? AND al.log_date >= ? AND al.log_date <= ?
      ORDER BY al.log_date DESC, al.scheduled_time ASC
    `)
    .all(patientId, startDate14, todayStr) as Array<{
    id: number;
    schedule_id: number | null;
    medication_id: number;
    medicine_name: string;
    dosage: string;
    log_date: string;
    scheduled_time: string;
    confirmation_time: string | null;
    reported_taken_time: string | null;
    status: 'taken' | 'retroactive' | 'missed' | 'pending' | 'snoozed';
    confirmation_type: string;
    note: string;
  }>;

  // Combine historical logs + today's unresolved scheduled doses for accurate weekly scorecard
  const combinedRecords: AdherenceRecord[] = historicalLogs.map((l) => ({
    date: l.log_date,
    status: l.status,
    scheduled_time: l.scheduled_time,
    confirmation_time: l.confirmation_time,
  }));

  for (const dose of todayDoses) {
    if (!dose.log) {
      combinedRecords.push({
        date: todayStr,
        status: dose.state === 'overdue' ? 'overdue' : 'pending',
        scheduled_time: dose.scheduled_time,
        confirmation_time: null,
      });
    }
  }

  const weeklyRecords = combinedRecords.filter((r) => last7Dates.includes(r.date));
  const weeklyStats = computeAdherenceStats(weeklyRecords);
  const weeklyCalendar = computeDailyBreakdown(weeklyRecords, last7Dates);
  const calendar14Days = computeDailyBreakdown(combinedRecords, last14Dates);

  // Active alerts
  const alerts = db
    .prepare(`
      SELECT ca.*, m.medicine_name, m.dosage, m.remaining_quantity
      FROM caregiver_alerts ca
      JOIN medications m ON m.id = ca.medication_id
      WHERE ca.patient_id = ? AND ca.status = 'active'
      ORDER BY CASE WHEN ca.alert_type = 'missed_dose' THEN 0 ELSE 1 END, ca.created_at DESC
    `)
    .all(patientId);

  const refillWarnings = medications
    .map((m) => ({
      ...m,
      refillStatus: checkRefillWarning(m.remaining_quantity),
    }))
    .filter((m) => m.refillStatus.isLow);

  const medsWithSchedules = medications.map((m) => ({
    ...m,
    refillStatus: checkRefillWarning(m.remaining_quantity),
    schedules: schedules
      .filter((s) => s.medication_id === m.id)
      .map((s) => ({
        id: s.id,
        scheduled_time: s.scheduled_time,
        scheduled_time_12h: formatTime12Hour(s.scheduled_time),
        schedule_period: s.schedule_period,
        active: s.active,
      })),
  }));

  return {
    patient,
    caregiver: caregiver ?? null,
    today: todayStr,
    nowMinutes,
    medications: medsWithSchedules,
    todayDoses,
    weeklyStats,
    weeklyCalendar,
    calendar14Days,
    historicalLogs,
    alerts,
    refillWarnings,
  };
}

export function confirmDoseSafely(
  db: DatabaseSync,
  params: {
    patientId: number;
    medicationId: number;
    scheduleId: number;
    logDate: string;
    confirmationTimeISO: string;
    confirmationType: 'senior_tap' | 'retroactive';
    reportedTakenTime?: string | null;
    note?: string;
  }
): {
  alreadyConfirmed: boolean;
  log: Record<string, unknown>;
  remainingQuantity: number;
} {
  const existing = db
    .prepare('SELECT * FROM adherence_logs WHERE schedule_id = ? AND log_date = ?')
    .get(params.scheduleId, params.logDate) as
    | { id: number; status: string; confirmation_time: string | null }
    | undefined;

  const med = db
    .prepare('SELECT id, remaining_quantity, medicine_name, dosage FROM medications WHERE id = ?')
    .get(params.medicationId) as
    | { id: number; remaining_quantity: number; medicine_name: string; dosage: string }
    | undefined;

  const sched = db
    .prepare('SELECT scheduled_time FROM dose_schedules WHERE id = ?')
    .get(params.scheduleId) as { scheduled_time: string } | undefined;

  if (!med || !sched) {
    throw new Error('Medication or schedule not found.');
  }

  if (existing && (existing.status === 'taken' || existing.status === 'retroactive')) {
    return {
      alreadyConfirmed: true,
      log: existing as Record<string, unknown>,
      remainingQuantity: med.remaining_quantity,
    };
  }

  const nextQty = decrementInventory(med.remaining_quantity, 1);

  db.exec('BEGIN TRANSACTION;');
  try {
    if (existing) {
      db.prepare(`
        UPDATE adherence_logs
        SET confirmation_time = ?,
            reported_taken_time = ?,
            status = ?,
            confirmation_type = ?,
            note = ?
        WHERE id = ?
      `).run(
        params.confirmationTimeISO,
        params.reportedTakenTime ?? null,
        params.confirmationType === 'retroactive' ? 'retroactive' : 'taken',
        params.confirmationType,
        params.note ?? '',
        existing.id
      );
    } else {
      db.prepare(`
        INSERT INTO adherence_logs (
          patient_id, medication_id, schedule_id, log_date, scheduled_time,
          confirmation_time, reported_taken_time, status, confirmation_type, note
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).run(
        params.patientId,
        params.medicationId,
        params.scheduleId,
        params.logDate,
        sched.scheduled_time,
        params.confirmationTimeISO,
        params.reportedTakenTime ?? null,
        params.confirmationType === 'retroactive' ? 'retroactive' : 'taken',
        params.confirmationType,
        params.note ?? ''
      );
    }

    db.prepare('UPDATE medications SET remaining_quantity = ? WHERE id = ?').run(
      nextQty,
      params.medicationId
    );

    db.prepare(
      'UPDATE dose_schedules SET snoozed_until_date = NULL, snoozed_until_time = NULL WHERE id = ?'
    ).run(params.scheduleId);

    // Resolve any active missed_dose alert for this schedule & date
    db.prepare(`
      UPDATE caregiver_alerts
      SET status = 'resolved', resolved_at = datetime('now')
      WHERE schedule_id = ? AND alert_date = ? AND alert_type = 'missed_dose' AND status = 'active'
    `).run(params.scheduleId, params.logDate);

    // Create refill warning alert if below 5 and none active
    const refillStatus = checkRefillWarning(nextQty);
    if (refillStatus.isLow) {
      const activeRefill = db
        .prepare(
          "SELECT id FROM caregiver_alerts WHERE medication_id = ? AND alert_type = 'refill_low' AND status = 'active'"
        )
        .get(params.medicationId) as { id: number } | undefined;

      const msg = `${med.medicine_name} ${med.dosage} is running low (${nextQty} pills remaining).`;
      if (activeRefill) {
        db.prepare('UPDATE caregiver_alerts SET message = ? WHERE id = ?').run(
          msg,
          activeRefill.id
        );
      } else {
        db.prepare(`
          INSERT INTO caregiver_alerts (
            patient_id, medication_id, schedule_id, alert_date, scheduled_time, alert_type, message, status
          ) VALUES (?, ?, NULL, ?, '', 'refill_low', ?, 'active')
        `).run(params.patientId, params.medicationId, params.logDate, msg);
      }
    }

    db.exec('COMMIT;');
  } catch (err) {
    db.exec('ROLLBACK;');
    throw err;
  }

  const savedLog = db
    .prepare('SELECT * FROM adherence_logs WHERE schedule_id = ? AND log_date = ?')
    .get(params.scheduleId, params.logDate) as Record<string, unknown>;

  return {
    alreadyConfirmed: false,
    log: savedLog,
    remainingQuantity: nextQty,
  };
}
