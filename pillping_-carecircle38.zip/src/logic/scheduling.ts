export type DoseState = 'taken' | 'snoozed' | 'due' | 'overdue' | 'upcoming';

export interface AdherenceRecord {
  date: string; // YYYY-MM-DD
  status: 'taken' | 'retroactive' | 'missed' | 'pending' | 'snoozed' | 'overdue';
  scheduled_time?: string;
  confirmation_time?: string | null;
}

export interface AdherenceSummary {
  totalScheduled: number;
  completed: number;
  missed: number;
  pending: number;
  adherencePercentage: number;
}

export interface DailyCalendarEntry {
  date: string;
  total: number;
  completed: number;
  missed: number;
  pending: number;
  colorStatus: 'green' | 'red' | 'yellow' | 'neutral';
  adherencePercentage: number;
}

export interface RefillStatus {
  isLow: boolean;
  isEmpty: boolean;
  severity: 'ok' | 'low' | 'critical';
}

export const DEFAULT_GRACE_WINDOW_MINUTES = 30;
export const DEFAULT_REFILL_THRESHOLD = 5;
export const MAX_IMAGE_BYTES = 1_500_000;

/**
 * Converts HH:MM (24-hour) string to minutes since midnight.
 */
export function parseTimeToMinutes(hhmm: string): number {
  const match = /^([01]?\d|2[0-3]):([0-5]\d)$/.exec(hhmm.trim());
  if (!match) {
    throw new Error(`Invalid HH:MM time format: "${hhmm}"`);
  }
  const hours = Number(match[1]);
  const minutes = Number(match[2]);
  return hours * 60 + minutes;
}

/**
 * Formats HH:MM (24-hour) or minutes since midnight into "10:00 AM" format.
 */
export function formatTime12Hour(timeInput: string | number): string {
  const totalMinutes =
    typeof timeInput === 'number' ? timeInput : parseTimeToMinutes(timeInput);
  const normalized = ((totalMinutes % 1440) + 1440) % 1440;
  const hours24 = Math.floor(normalized / 60);
  const mins = normalized % 60;
  const period = hours24 >= 12 ? 'PM' : 'AM';
  const hours12 = hours24 % 12 === 0 ? 12 : hours24 % 12;
  return `${hours12}:${String(mins).padStart(2, '0')} ${period}`;
}

/**
 * Classifies a scheduled medication dose for today into one of 5 states.
 * Enforces the 30-minute grace window before escalating to overdue.
 */
export function classifyDoseState(params: {
  scheduledTimeHHMM: string;
  currentTimeMinutes: number;
  isTaken: boolean;
  snoozedUntilMinutes?: number | null;
  graceWindowMinutes?: number;
}): DoseState {
  const {
    scheduledTimeHHMM,
    currentTimeMinutes,
    isTaken,
    snoozedUntilMinutes = null,
    graceWindowMinutes = DEFAULT_GRACE_WINDOW_MINUTES,
  } = params;

  if (isTaken) {
    return 'taken';
  }

  const scheduledMinutes = parseTimeToMinutes(scheduledTimeHHMM);

  if (snoozedUntilMinutes !== null && snoozedUntilMinutes !== undefined) {
    if (currentTimeMinutes < snoozedUntilMinutes) {
      return 'snoozed';
    }
    if (currentTimeMinutes <= snoozedUntilMinutes + graceWindowMinutes) {
      return 'due';
    }
    return 'overdue';
  }

  if (currentTimeMinutes < scheduledMinutes) {
    return 'upcoming';
  }

  if (currentTimeMinutes <= scheduledMinutes + graceWindowMinutes) {
    return 'due';
  }

  return 'overdue';
}

/**
 * Calculates how many minutes a dose has remained unconfirmed past its scheduled (or snoozed) time.
 */
export function getMinutesOverdue(params: {
  scheduledTimeHHMM: string;
  currentTimeMinutes: number;
  snoozedUntilMinutes?: number | null;
}): number {
  const targetMinutes =
    params.snoozedUntilMinutes !== null && params.snoozedUntilMinutes !== undefined
      ? params.snoozedUntilMinutes
      : parseTimeToMinutes(params.scheduledTimeHHMM);
  return Math.max(0, params.currentTimeMinutes - targetMinutes);
}

/**
 * Computes medication adherence statistics from real log entries.
 * Adherence percentage = completed / (completed + missed), defaulting to 100 when none resolved yet.
 */
export function computeAdherenceStats(records: AdherenceRecord[]): AdherenceSummary {
  let completed = 0;
  let missed = 0;
  let pending = 0;

  for (const record of records) {
    if (record.status === 'taken' || record.status === 'retroactive') {
      completed += 1;
    } else if (record.status === 'missed') {
      missed += 1;
    } else {
      pending += 1;
    }
  }

  const totalScheduled = completed + missed + pending;
  const resolvedCount = completed + missed;
  const adherencePercentage =
    resolvedCount > 0 ? Math.round((completed / resolvedCount) * 100) : 100;

  return {
    totalScheduled,
    completed,
    missed,
    pending,
    adherencePercentage,
  };
}

/**
 * Builds daily compliance entries for a list of YYYY-MM-DD dates.
 * Green: all resolved doses completed with 0 missed & 0 pending.
 * Red: one or more missed doses.
 * Yellow: pending/overdue doses present (and 0 missed).
 */
export function computeDailyBreakdown(
  records: AdherenceRecord[],
  dates: string[]
): DailyCalendarEntry[] {
  const grouped = new Map<string, AdherenceRecord[]>();
  for (const date of dates) {
    grouped.set(date, []);
  }
  for (const record of records) {
    const bucket = grouped.get(record.date);
    if (bucket) {
      bucket.push(record);
    }
  }

  return dates.map((date) => {
    const dayRecords = grouped.get(date) ?? [];
    const stats = computeAdherenceStats(dayRecords);
    let colorStatus: DailyCalendarEntry['colorStatus'] = 'neutral';

    if (stats.totalScheduled > 0) {
      if (stats.missed > 0) {
        colorStatus = 'red';
      } else if (stats.pending > 0) {
        colorStatus = 'yellow';
      } else {
        colorStatus = 'green';
      }
    }

    return {
      date,
      total: stats.totalScheduled,
      completed: stats.completed,
      missed: stats.missed,
      pending: stats.pending,
      colorStatus,
      adherencePercentage: stats.adherencePercentage,
    };
  });
}

/**
 * Evaluates prescription refill threshold (< 5 pills triggers warning).
 */
export function checkRefillWarning(
  remainingQuantity: number,
  threshold: number = DEFAULT_REFILL_THRESHOLD
): RefillStatus {
  const safeQty = Math.max(0, Math.floor(remainingQuantity));
  if (safeQty === 0) {
    return { isLow: true, isEmpty: true, severity: 'critical' };
  }
  if (safeQty < threshold) {
    return { isLow: true, isEmpty: false, severity: 'low' };
  }
  return { isLow: false, isEmpty: false, severity: 'ok' };
}

/**
 * Decrements pill inventory safely without ever going below zero.
 */
export function decrementInventory(currentQuantity: number, amount: number = 1): number {
  const safeCurrent = Number.isFinite(currentQuantity) ? Math.max(0, Math.floor(currentQuantity)) : 0;
  const safeAmount = Number.isFinite(amount) ? Math.max(0, Math.floor(amount)) : 1;
  return Math.max(0, safeCurrent - safeAmount);
}

/**
 * Validates a base64 data URL image upload (type + max size).
 */
export function validateImageDataUrl(dataUrl: string): { valid: boolean; error?: string } {
  if (!dataUrl) {
    return { valid: true };
  }
  if (dataUrl.startsWith('/src/assets/')) {
    return { valid: true };
  }
  const match = /^data:(image\/(?:png|jpeg|jpg|webp));base64,([A-Za-z0-9+/=]+)$/.exec(dataUrl);
  if (!match) {
    return {
      valid: false,
      error: 'Bottle photo must be a PNG, JPEG, or WebP image.',
    };
  }
  const base64Body = match[2];
  const estimatedBytes = Math.floor((base64Body.length * 3) / 4);
  if (estimatedBytes > MAX_IMAGE_BYTES) {
    return {
      valid: false,
      error: 'Bottle photo must be smaller than 1.5 MB.',
    };
  }
  return { valid: true };
}

/**
 * Validates and normalizes phone numbers for Emergency SOS tel: links.
 */
export function validatePhoneNumber(phone: string): { valid: boolean; normalized: string; error?: string } {
  const trimmed = phone.trim();
  if (!trimmed) {
    return { valid: false, normalized: '', error: 'Phone number is required.' };
  }
  const cleaned = trimmed.replace(/[^\d+]/g, '');
  const digitsOnly = cleaned.replace(/\D/g, '');
  if (digitsOnly.length < 3 || digitsOnly.length > 15) {
    return {
      valid: false,
      normalized: '',
      error: 'Please enter a valid emergency phone number (3–15 digits).',
    };
  }
  return { valid: true, normalized: cleaned };
}
