import test from 'node:test';
import assert from 'node:assert/strict';
import {
  parseTimeToMinutes,
  formatTime12Hour,
  classifyDoseState,
  getMinutesOverdue,
  computeAdherenceStats,
  computeDailyBreakdown,
  checkRefillWarning,
  decrementInventory,
  validateImageDataUrl,
  validatePhoneNumber,
} from './scheduling';

test('parseTimeToMinutes and formatTime12Hour convert times accurately', () => {
  assert.equal(parseTimeToMinutes('00:05'), 5);
  assert.equal(parseTimeToMinutes('10:00'), 600);
  assert.equal(parseTimeToMinutes('21:30'), 1290);
  assert.equal(formatTime12Hour('10:00'), '10:00 AM');
  assert.equal(formatTime12Hour('00:00'), '12:00 AM');
  assert.equal(formatTime12Hour('12:15'), '12:15 PM');
  assert.equal(formatTime12Hour('20:45'), '8:45 PM');
  assert.throws(() => parseTimeToMinutes('25:99'));
});

test('classifyDoseState respects 30-minute grace window and snooze', () => {
  // 10:00 AM = 600 mins
  assert.equal(
    classifyDoseState({ scheduledTimeHHMM: '10:00', currentTimeMinutes: 590, isTaken: false }),
    'upcoming'
  );
  assert.equal(
    classifyDoseState({ scheduledTimeHHMM: '10:00', currentTimeMinutes: 600, isTaken: false }),
    'due'
  );
  // 10:25 AM is inside 30-minute grace window
  assert.equal(
    classifyDoseState({ scheduledTimeHHMM: '10:00', currentTimeMinutes: 625, isTaken: false }),
    'due'
  );
  // 10:30 AM is boundary (still within <= 30)
  assert.equal(
    classifyDoseState({ scheduledTimeHHMM: '10:00', currentTimeMinutes: 630, isTaken: false }),
    'due'
  );
  // 10:31 AM escalates to overdue
  assert.equal(
    classifyDoseState({ scheduledTimeHHMM: '10:00', currentTimeMinutes: 631, isTaken: false }),
    'overdue'
  );
  // Snoozed until 10:15 AM (615)
  assert.equal(
    classifyDoseState({
      scheduledTimeHHMM: '10:00',
      currentTimeMinutes: 610,
      isTaken: false,
      snoozedUntilMinutes: 615,
    }),
    'snoozed'
  );
  assert.equal(
    classifyDoseState({
      scheduledTimeHHMM: '10:00',
      currentTimeMinutes: 616,
      isTaken: false,
      snoozedUntilMinutes: 615,
    }),
    'due'
  );
  // Taken overrides everything
  assert.equal(
    classifyDoseState({ scheduledTimeHHMM: '10:00', currentTimeMinutes: 700, isTaken: true }),
    'taken'
  );
});

test('getMinutesOverdue computes elapsed unconfirmed minutes accurately', () => {
  assert.equal(getMinutesOverdue({ scheduledTimeHHMM: '10:00', currentTimeMinutes: 642 }), 42);
  assert.equal(getMinutesOverdue({ scheduledTimeHHMM: '10:00', currentTimeMinutes: 590 }), 0);
  assert.equal(
    getMinutesOverdue({
      scheduledTimeHHMM: '10:00',
      currentTimeMinutes: 650,
      snoozedUntilMinutes: 615,
    }),
    35
  );
});

test('computeAdherenceStats calculates real percentages including retroactive logs', () => {
  const stats = computeAdherenceStats([
    { date: '2026-11-19', status: 'taken' },
    { date: '2026-11-19', status: 'retroactive' },
    { date: '2026-11-19', status: 'missed' },
    { date: '2026-11-20', status: 'pending' },
  ]);

  assert.equal(stats.totalScheduled, 4);
  assert.equal(stats.completed, 2);
  assert.equal(stats.missed, 1);
  assert.equal(stats.pending, 1);
  // 2 / (2 + 1) = 66.66 -> 67%
  assert.equal(stats.adherencePercentage, 67);
});

test('computeDailyBreakdown produces green, red, and yellow compliance indicators', () => {
  const dates = ['2026-11-18', '2026-11-19', '2026-11-20', '2026-11-21'];
  const breakdown = computeDailyBreakdown(
    [
      { date: '2026-11-18', status: 'taken' },
      { date: '2026-11-18', status: 'taken' },
      { date: '2026-11-19', status: 'taken' },
      { date: '2026-11-19', status: 'missed' },
      { date: '2026-11-20', status: 'taken' },
      { date: '2026-11-20', status: 'pending' },
    ],
    dates
  );

  assert.equal(breakdown[0].colorStatus, 'green');
  assert.equal(breakdown[1].colorStatus, 'red');
  assert.equal(breakdown[2].colorStatus, 'yellow');
  assert.equal(breakdown[3].colorStatus, 'neutral');
});

test('refill warning triggers below 5 pills and inventory never goes negative', () => {
  assert.deepEqual(checkRefillWarning(10), { isLow: false, isEmpty: false, severity: 'ok' });
  assert.deepEqual(checkRefillWarning(5), { isLow: false, isEmpty: false, severity: 'ok' });
  assert.deepEqual(checkRefillWarning(4), { isLow: true, isEmpty: false, severity: 'low' });
  assert.deepEqual(checkRefillWarning(0), { isLow: true, isEmpty: true, severity: 'critical' });
  assert.equal(decrementInventory(1, 1), 0);
  assert.equal(decrementInventory(0, 1), 0);
});

test('image and phone number validators reject invalid payloads', () => {
  assert.equal(validateImageDataUrl('data:image/png;base64,iVBORw0KGgo=').valid, true);
  assert.equal(validateImageDataUrl('data:text/html;base64,PHNjcmlwdD4=').valid, false);
  assert.equal(validatePhoneNumber('+1 (555) 014-2000').valid, true);
  assert.equal(validatePhoneNumber('+1 (555) 014-2000').normalized, '+15550142000');
  assert.equal(validatePhoneNumber('abc').valid, false);
});
