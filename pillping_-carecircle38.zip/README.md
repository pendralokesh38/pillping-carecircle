# PillPing: CareCircle

A senior-friendly, high-contrast medication management and real-time caregiver oversight web application.

## Key Features

- **Senior / Elderly Interface (`/`)**:
  - High-contrast daylight palette with extra-large typography and minimum `64 × 64 px` interactive touch targets.
  - Full-screen medication reminder overlay showing medicine name, dosage, scheduled time, food/water instructions, and caregiver-uploaded pill bottle photo.
  - One-tap **"I Took My Medicine"** confirmation with uplifting green confirmation screen (`"Good Job, Dad!"`), Web Audio confirmation chime, duplicate-tap protection, and automatic pill inventory deduction.
  - Prominent **"Snooze 15 Mins"** rescheduling.
  - Multi-language **Voice Read-Aloud** via the browser Web Speech API (`en-US`, `es-ES`, `hi-IN`, `fr-FR`, `zh-CN`).
  - **Emergency SOS Quick Dial** with accidental-activation guard and configurable caregiver phone link (`tel:`).
- **Caregiver Dashboard (`/caregiver.html`)**:
  - Real-time synchronization via Server-Sent Events (`GET /api/events`) — updates immediately when a senior confirms or snoozes a dose.
  - **30-Minute Missed Dose Escalation**: Automatically generates urgent alerts when a dose goes unconfirmed past its 30-minute grace window.
  - **"Already Took It" Retroactive Confirmation**: Differentiates missed doses from forgotten button taps, recording both the reported taken time and the actual caregiver audit timestamp.
  - **Weekly Adherence Scorecard & 14-Day Color-Coded Compliance Calendar**: Dynamically computed from SQLite adherence logs (`Green` complete, `Yellow` pending/overdue, `Red` missed).
  - **Medication & Schedule Configurator**: Add, edit, and delete medications, configure Morning/Afternoon/Night schedules, upload/preview pill bottle photos, and track refill inventory (automatic warnings below 5 remaining pills).
- **2-Patient 14-Day Sample Demonstration Dataset**:
  - Automatically seeds **Robert Miller** (Age 74) and **Eleanor Vance** (Age 78) with Metformin, Amlodipine, Aspirin, Atorvastatin/Lisinopril, and 14 days of realistic adherence logs.

## Project Structure

```
├── index.html                  # Senior / Elderly User Interface
├── caregiver.html              # Caregiver Oversight Dashboard
├── server.ts                   # Express REST API, SSE stream, escalation timer & Vite middleware
├── public/
│   └── reminder-worker.js      # Web Worker for background reminder evaluation
├── src/
│   ├── css/
│   │   ├── style.css           # Shared design tokens, typography, pill color coding
│   │   ├── senior.css          # Senior UI high-contrast & >=64px target rules
│   │   └── caregiver.css       # Caregiver dashboard layout & calendar styles
│   ├── js/
│   │   ├── api.js              # REST API client & SSE EventSource subscriber
│   │   ├── app.js              # Senior interface controller
│   │   ├── caregiver.js        # Caregiver dashboard controller
│   │   ├── medications.js      # Medication CRUD modal & bottle photo validation
│   │   ├── adherence.js        # Weekly scorecard & 14-day calendar renderer
│   │   ├── notifications.js    # Web Notifications API & Web Audio chimes
│   │   ├── reminders.js        # Web Worker & visibilitychange recovery scheduler
│   │   └── voice.js            # Web Speech API multi-language read-aloud
│   ├── db/
│   │   └── database.ts         # SQLite (node:sqlite) schema, seeding & transactions
│   ├── logic/
│   │   ├── scheduling.ts       # Pure scheduling, adherence, refill & validation logic
│   │   └── scheduling.test.ts  # Node test suite (node:test)
│   └── data/
│       └── sampleDataset.json  # 2-patient demonstration dataset
```

## Setup & Running Locally

Requires **Node.js v22+** (uses built-in `node:sqlite`).

1. Install dependencies:
   ```bash
   npm install
   ```
2. Run unit tests:
   ```bash
   npm test
   ```
3. Start the development server (port 3000):
   ```bash
   npm run dev
   ```
4. Build & run for production:
   ```bash
   npm run build
   npm start
   ```
5. Open:
   - Senior Interface: `http://localhost:3000/`
   - Caregiver Dashboard: `http://localhost:3000/caregiver.html`

## API Endpoints

| Method | Endpoint | Description |
| :--- | :--- | :--- |
| `GET` | `/api/health` | Server & SQLite health status |
| `GET` | `/api/events` | Server-Sent Events (SSE) stream for live dashboard sync |
| `GET` | `/api/patients` | List patients with assigned primary caregiver |
| `GET` | `/api/patients/:id/dashboard` | Synchronized patient schedule, stats, calendar, and alerts |
| `PUT` | `/api/patients/:id/contact` | Update caregiver emergency SOS phone & greeting name |
| `POST` | `/api/medications` | Create medication, schedules, and optional bottle photo |
| `PUT` | `/api/medications/:id` | Update medication, schedules, and bottle photo |
| `DELETE` | `/api/medications/:id` | Delete medication and cascade schedules |
| `POST` | `/api/medications/:id/refill` | Add pills to remaining inventory and clear low-refill alert |
| `POST` | `/api/doses/confirm` | Senior one-tap confirmation (idempotent; prevents double-counting) |
| `POST` | `/api/doses/snooze` | Snooze dose reminder by 15 minutes |
| `POST` | `/api/doses/retroactive` | Caregiver "Already Took It" retroactive confirmation |
| `POST` | `/api/doses/miss` | Caregiver marks an overdue dose as missed |
| `POST` | `/api/alerts/:id/resolve` | Dismiss/resolve an active alert |
| `POST` | `/api/alerts/check-escalations` | Run 30-minute missed-dose escalation check |
| `POST` | `/api/demo/simulate-overdue` | Shift an unconfirmed dose 42 mins past due for escalation demo |
| `POST` | `/api/demo/reset` | Restore the 2-patient 14-day demonstration dataset |

## Browser Timer Limitations

Browser-based Web Workers and Web Notifications execute reliably while the browser tab remains open or minimized. Standard web browsers pause client-side timers if the tab or browser application is completely closed. For continuous audible reminders on a senior's tablet or desktop, keep the PillPing tab open.

## Verification Steps

1. Run `npm test` to verify scheduling, 30-minute grace window, adherence math, refill thresholds, and input validators.
2. Open `/` in Tab 1 (Senior View) and `/caregiver.html` in Tab 2 (Caregiver View).
3. Click **Show 10:00 AM Reminder** (or wait for a scheduled dose) -> verify bottle photo, **"Take with Water"**, and chime -> click **"I Took My Medicine"** -> verify **"Good Job, Dad!"** green confirmation and immediate green checkmark update in Tab 2.
4. On Tab 2, click **Simulate 30+ Min Overdue Dose Alert** -> verify urgent alert appears -> click **"Already Took It"** -> verify retroactive confirmation audit record and recalculated weekly adherence percentage.
