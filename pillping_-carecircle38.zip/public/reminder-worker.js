// Web Worker for background medication reminder scheduling while browser tab is open.
// Note: Browsers throttle or pause JS execution when a tab or browser is completely closed.

let schedules = [];
let notifiedKeys = new Set();
let checkTimer = null;

function getLocalClock() {
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const d = String(now.getDate()).padStart(2, '0');
  const dateStr = `${y}-${m}-${d}`;
  const minutes = now.getHours() * 60 + now.getMinutes();
  return { dateStr, minutes };
}

function parseMinutes(hhmm) {
  const parts = String(hhmm || '').split(':');
  if (parts.length !== 2) return null;
  const h = Number(parts[0]);
  const m = Number(parts[1]);
  if (!Number.isFinite(h) || !Number.isFinite(m)) return null;
  return h * 60 + m;
}

function evaluateSchedules() {
  if (!Array.isArray(schedules) || schedules.length === 0) return;
  const { dateStr, minutes } = getLocalClock();

  for (const dose of schedules) {
    if (!dose || dose.state === 'taken' || dose.state === 'missed') {
      continue;
    }

    const targetTime = dose.snoozed_until_time || dose.scheduled_time;
    const targetMinutes = parseMinutes(targetTime);
    if (targetMinutes === null) continue;

    // Trigger reminder if current time is at or past targetTime and within 30-min grace window
    const diff = minutes - targetMinutes;
    if (diff >= 0 && diff <= 30) {
      const key = `${dateStr}:${dose.schedule_id}:${targetTime}`;
      if (!notifiedKeys.has(key)) {
        notifiedKeys.add(key);
        self.postMessage({
          type: 'REMINDER_DUE',
          dose,
          triggeredAt: new Date().toISOString(),
        });
      }
    }
  }
}

self.addEventListener('message', (event) => {
  const msg = event.data;
  if (!msg || typeof msg !== 'object') return;

  if (msg.type === 'UPDATE_SCHEDULES') {
    schedules = Array.isArray(msg.schedules) ? msg.schedules : [];
    evaluateSchedules();
  } else if (msg.type === 'CHECK_NOW') {
    evaluateSchedules();
  } else if (msg.type === 'RESET_NOTIFIED') {
    notifiedKeys.clear();
  }
});

// Check every 15 seconds for accurate reminder timing
checkTimer = setInterval(evaluateSchedules, 15000);
